from __future__ import annotations

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")

from flask import Flask, render_template, jsonify, request
import numpy as np
import json
import copy
import csv
import random
import hashlib
import math
from collections import deque
from threading import Lock
from typing import Any, Dict, List, Tuple, Optional
from abc import ABC, abstractmethod
from brain.orchestrator import BrainOrchestrator
from brain.components.locus_coeruleus import LocusCoeruleusComponent
from brain.components.basal_forebrain import BasalForebrainComponent
from brain.components.sensory import VisionCortexComponent, SomatoCortexComponent
from brain.components.basal_ganglia import BasalGangliaComponent
from predator import Predator

class CoherenceField(ABC):
    """
    Interface for any continuous field dynamics (Quantum or Classical).
    Required for ablation studies.
    """
    
    @abstractmethod
    def step(self, pump_map: np.ndarray, **kwargs) -> Tuple[np.ndarray, bool]:
        """
        Advance physics by one step.
        Args:
            pump_map: 2D array of input energy.
        Returns:
            (viz_density, collapse_event): 
                - viz_density: 2D array for UI heatmap.
                - collapse_event: Boolean indicating state reset/decision.
        """
        pass

    @abstractmethod
    def get_readouts(self) -> Dict[str, float]:
        """Return metrics: coherence, entropy, contrast, collapse_ema."""
        pass
    
    @abstractmethod
    def reset_wavefunction(self):
        """Reset internal state to baseline."""
        pass

    @property
    @abstractmethod
    def avg_coherence(self) -> float:
        """Expose current coherence for downstream gating."""
        pass

    @abstractmethod
    def get_fingerprint_bytes(self) -> bytes:
        """Return bytes representing current state for deterministic hashing."""
        pass

app = Flask(__name__)

# Serialize access to global simulation state (single-user demo safety)
sim_lock = Lock()

# --- MAP STORAGE HELPERS ---
CUSTOM_MAPS_FILE = "custom_maps.json"


def load_custom_maps_data():
    if "sim" in globals() and getattr(sim, "config", {}).get("deterministic", 0.0) > 0.5:
        return {}
    if not os.path.exists(CUSTOM_MAPS_FILE):
        return {}
    try:
        with open(CUSTOM_MAPS_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def save_custom_maps_data(data):
    if "sim" in globals() and getattr(sim, "config", {}).get("deterministic", 0.0) > 0.5:
        return
    with open(CUSTOM_MAPS_FILE, "w") as f:
        json.dump(data, f)


# --- PHYSICS ENGINE ---
COMPLEX_TYPE = np.complex128


def clamp(x: float, lo: float, hi: float) -> float:
    return float(max(lo, min(hi, x)))


def angdiff(a: float, b: float) -> float:
    """Smallest absolute angular difference between angles a and b (radians)."""
    d = (a - b + np.pi) % (2 * np.pi) - np.pi
    return abs(d)


def finite_or_zero(arr: np.ndarray) -> np.ndarray:
    return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)


def ema(prev: float, target: float, tau: float, dt: float) -> float:
    a = float(np.exp(-dt / max(tau, 1e-9)))
    return a * prev + (1.0 - a) * target


BASE_DT = 0.05  # legacy timestep


def maybe_downsample(arr: np.ndarray, ds: int) -> np.ndarray:
    """Downsample a 2D array by stride ds (ds=1 => no-op)."""
    if ds <= 1:
        return arr
    if arr.ndim == 1:
        return arr[::ds]
    if arr.ndim == 2:
        return arr[::ds, ::ds]
    return arr


class MicrotubuleSimulator2D(CoherenceField):
    def __init__(self, label, length_points=32, seam_shift=3, dt=0.01, neighbor_mode: str = "legacy", rng=None):
        if rng is None:
            raise ValueError("MicrotubuleSimulator2D requires rng injection")
        self.label = label
        # In this model: X=13 (Circumference/Protofilaments), Y=Length
        self.Nx = 13
        self.Ny = length_points
        self.dt = dt
        self.seam_shift = seam_shift
        self.neighbor_mode = neighbor_mode
        self.rng = rng
        self.deterministic_mode = False

        # Physics Constants (normalized)
        self.H_BAR = 1.0
        self.base_gamma = 1.5

        # State Arrays
        self.psi = np.zeros((self.Ny, self.Nx), dtype=COMPLEX_TYPE)
        self.superradiance = np.zeros((self.Ny, self.Nx), dtype=float)
        self.accumulated_Eg = 0.0

        # Phases: "ISOLATION" (Classical), "SUPERPOSITION" (Quantum), "COLLAPSE"
        self.phase = "ISOLATION"
        
        # --- FIX 1: Initialize internal variable ---
        self._avg_coherence = 0.0 
        
        self.readout = {"coherence":0.0, "entropy":0.0, "contrast":0.0, "collapse_ema":0.0}
        self.collapse_ema = 0.0
        self.reset_wavefunction()

    # --- FIX 2: Add the required property ---
    @property
    def avg_coherence(self) -> float:
        return self._avg_coherence

    def reset_wavefunction(self):
        noise_r = 0.1 * (self.rng.random((self.Ny, self.Nx)) - 0.5)
        noise_i = 0.1 * (self.rng.random((self.Ny, self.Nx)) - 0.5)
        self.psi = (noise_r + 1j * noise_i).astype(COMPLEX_TYPE)
        self.superradiance.fill(0.0)
        self.accumulated_Eg = 0.0
        self.phase = "ISOLATION"

    def get_helical_neighbor(self, grid: np.ndarray, dx: int, dy: int) -> np.ndarray:
        """
        Neighbor grid shifted by dx (circumference) and dy (length).

        - X wraps (cylindrical) with seam shift correction.
        - Y is OPEN ENDED (no wrapping): values shifted past ends are zeroed.
        """
        # Shift Y
        shifted = np.roll(grid, dy, axis=0)

        # Open ends: zero the wrapped-in row
        if dy == 1:
            shifted[0, :] = 0.0
        elif dy == -1:
            shifted[-1, :] = 0.0

        # Shift X with helical seam correction
        if dx == 0:
            return shifted

        temp_grid = np.roll(shifted, dx, axis=1)

        # Correct the seam wrap column by shifting along Y
        if dx == 1:
            temp_grid[:, 0] = np.roll(temp_grid[:, 0], self.seam_shift)
            # after shifting seam column in Y, enforce open ends again
            temp_grid[0, 0] = 0.0
            temp_grid[-1, 0] = 0.0
        elif dx == -1:
            temp_grid[:, -1] = np.roll(temp_grid[:, -1], -self.seam_shift)
            temp_grid[0, -1] = 0.0
            temp_grid[-1, -1] = 0.0

        return temp_grid

    def step(self, pump_map: np.ndarray, lfp_signal: float = 0.0, anesthetic_conc: float = 0.0) -> Tuple[np.ndarray, bool]:
        anesthetic_conc = clamp(float(anesthetic_conc), 0.0, 1.0)

        # Anesthesia dampens input sensitivity
        effective_pump = pump_map * (1.0 - anesthetic_conc)

        # 1) Update Superradiance (pumping vs decay)
        decay_rate = 0.1
        self.superradiance = self.superradiance * (1 - decay_rate) + (effective_pump * 0.2)
        self.superradiance = np.clip(self.superradiance, 0.0, 1.0)

        # 2) Dipole coupling field
        neighbors_canonical = [
            (1, 0, 1.0),
            (-1, 0, 1.0),
            (0, 1, 0.58),
            (0, -1, 0.58),
            (1, 1, 0.4),
            (-1, -1, 0.4),
        ]
        neighbors_legacy = [
            (0, 1, 1.0),
            (0, -1, 1.0),
            (1, 0, 0.58),
            (-1, 0, 0.58),
            (1, 1, 0.4),
            (-1, -1, 0.4),
        ]
        neighbors = neighbors_canonical if self.neighbor_mode == "canonical" else neighbors_legacy

        dipole_potential = np.zeros_like(self.psi, dtype=COMPLEX_TYPE)

        for dx, dy, coupling in neighbors:
            psi_neighbor = self.get_helical_neighbor(self.psi, dx, dy)
            effective_coupling = coupling
            if dx != 0:
                effective_coupling *= (1.0 - anesthetic_conc)
            dipole_potential += effective_coupling * psi_neighbor

        # 3) Phase Dynamics
        collapse_event = False
        avg_coherence = float(np.mean(self.superradiance))
        if self.deterministic_mode:
            avg_coherence = float(np.round(avg_coherence, 10))

        if avg_coherence < 0.2:
            # Classical-ish relaxation
            self.phase = "ISOLATION"
            d_psi = (np.real(dipole_potential) - 4 * self.psi) * 0.1
            self.psi += d_psi
            self.psi /= (np.max(np.abs(self.psi)) + 1e-9)
        else:
            if self.phase == "ISOLATION":
                self.phase = "SUPERPOSITION"
                self.accumulated_Eg = 0.0

            density = np.abs(self.psi) ** 2
            nonlinear = self.base_gamma * density * self.psi

            # Pump drives Schrödinger-like evolution
            d_psi = -1j * (dipole_potential + nonlinear) + (effective_pump * self.psi)
            self.psi += d_psi * self.dt

            # Update Eg based on *current* density (recompute)
            density_now = np.abs(self.psi) ** 2
            current_Eg = float(np.var(density_now) * 10.0)
            if self.deterministic_mode:
                current_Eg = float(np.round(current_Eg, 10))
            self.accumulated_Eg += current_Eg * self.dt
            if self.deterministic_mode:
                self.accumulated_Eg = float(np.round(self.accumulated_Eg, 10))

            if self.accumulated_Eg > self.H_BAR:
                self.phase = "COLLAPSE"
                collapse_event = True
                # Collapse decision uses the latest density
                mean_d = float(np.mean(density_now))
                if self.rng.random() > 0.5:
                    self.psi = np.where(density_now > mean_d, 1.0 + 0j, 0.0 + 0j)
                else:
                    self.reset_wavefunction()
                self.accumulated_Eg = 0.0
                self.phase = "ISOLATION"

        self._avg_coherence = avg_coherence
        self.collapse_ema = ema(self.collapse_ema, 1.0 if collapse_event else 0.0, tau=2.0, dt=self.dt)
        self.readout = self.get_readouts()
        
        # Normalize
        norm = float(np.linalg.norm(self.psi))
        if norm > 0:
            self.psi /= norm

        # IMPORTANT FIX: viz density must be computed from the updated psi
        density_viz = np.abs(self.psi) ** 2
        viz_density = density_viz * 200.0

        return viz_density, collapse_event

    def get_readouts(self) -> Dict[str, float]:
        density = np.abs(self.psi) ** 2
        
        # Coherence
        coherence = self._avg_coherence

        # Entropy
        p = density / (np.sum(density) + 1e-9)
        entropy = -np.sum(p * np.log(p + 1e-9)) / np.log(self.psi.size)
        
        # Contrast
        contrast = np.var(density)

        return {
            "coherence": coherence,
            "entropy": entropy,
            "contrast": contrast,
            "collapse_ema": self.collapse_ema
        }

    def get_fingerprint_bytes(self) -> bytes:
        return self.psi.astype(np.complex128).tobytes()


class OUNoiseField(CoherenceField):
    """
    Ornstein-Uhlenbeck Process.
    Ablation Control: Simulates 'activity' without quantum coherence or computation.
    """
    def __init__(self, label, length_points=32, dt=0.05, rng=None, **kwargs):
        self.label = label
        self.Ny = length_points
        self.Nx = 13
        self.dt = dt
        self.rng = rng
        
        # State is just scalar activity, not complex wavefunction
        self.state = np.zeros((self.Ny, self.Nx), dtype=float)
        self.tau = 0.5    # Time constant
        self.sigma = 0.2  # Noise volatility
        self.readout = {"coherence": 0.0, "entropy": 0.0, "contrast": 0.0, "collapse_ema": 0.0}
        self._avg_coherence = 0.0

    def step(self, pump_map: np.ndarray, lfp_signal: float = 0.0, anesthetic_conc: float = 0.0) -> Tuple[np.ndarray, bool]:
        # Ornstein-Uhlenbeck update: dx = -theta*x*dt + sigma*dW
        
        current_sigma = self.sigma
        if anesthetic_conc > 0.5:
            current_sigma *= 0.1 # 90% reduction

        noise = self.rng.normal(0.0, 1.0, self.state.shape)
        
        # Pump map acts as external drive (forcing function)
        drive = pump_map * 0.5
        
        dx = (-(self.state - drive) / self.tau) * self.dt + (current_sigma * np.sqrt(self.dt) * noise)
        self.state += dx
        
        # Clamp to reasonable range [0, 1] for biology-like firing
        self.state = np.clip(self.state, 0.0, 2.0)
        
        # Fake "Collapse": Random bursts that reset state
        # Matched to occur roughly as often as Orch-OR events (~1-2Hz)
        collapse = False
        if self.rng.random() < (0.02 * np.mean(pump_map)):
            self.state.fill(0.0)
            collapse = True
        
        # Compute metrics expected by brain
        density = self.state # In this model, state IS density
        self._avg_coherence = float(np.mean(density)) 
        
        # Entropy of the noise distribution
        p = density / (np.sum(density) + 1e-9)
        entropy = -np.sum(p * np.log(p + 1e-9))
        
        self.readout = {
            "coherence": self._avg_coherence,
            "entropy": entropy,
            "contrast": float(np.var(density)),
            "collapse_ema": 0.0 # Not tracked in null model
        }
        
        # Return matched format: (Density Map for UI, Collapse Bool)
        return self.state * 128.0, collapse

    def get_readouts(self) -> Dict[str, float]:
        return self.readout

    def reset_wavefunction(self):
        self.state.fill(0.0)

    @property
    def avg_coherence(self) -> float:
        return self._avg_coherence

    def get_fingerprint_bytes(self) -> bytes:
        return self.state.astype(np.float64).tobytes()


class Astrocyte:
    def __init__(self):
        self.glycogen = 1.0
        self.astro_lactate = 0.5
        self.ext_lactate = 0.5
        self.neuron_lactate = 0.5
        self.neuronal_atp = 1.0
        self.glutamate_load = 0.0

        self.Vmax_MCT4 = 0.8
        self.Km_MCT4 = 4.0

        self.Vmax_MCT2 = 0.6
        self.Km_MCT2 = 0.5

    def step(self, basal_firing: float, cortical_load: float, dt: float = 0.05):
        """
        Re-tuned metabolic model.
        - basal_firing: standard upkeep (0.0 to ~1.0)
        - cortical_load: intense computation (0.0 to 1.0)
        """
        basal_firing = float(max(0.0, basal_firing))
        cortical_load = float(max(0.0, cortical_load))

        # 1. Tuning Demand (The "Cost")
        # OLD: cortical_demand = cortical_load * 5.0 (Too aggressive)
        # NEW: cortical_demand = cortical_load * 2.5 (High, but sustainable for short bursts)
        cortical_demand = cortical_load * 2.5 
        
        # Total energy demand signal
        # Basal firing is cheap; Cortical load is the main driver of depletion.
        demand = (basal_firing * 0.05) + (cortical_demand * 0.1)
        self.glutamate_load += demand

        # 2. Glycogenolysis (Spending the Battery)
        # We reduce the rate multiplier from 0.05 to 0.02 to slow the drain.
        glycolysis_rate = 0.02 * self.glutamate_load * self.glycogen
        self.glycogen -= glycolysis_rate * dt
        self.astro_lactate += glycolysis_rate * dt

        # 3. Glycogenesis (Recharging the Battery)
        # Real astrocytes recharge from blood glucose constantly.
        # We add a recharge term that works when demand is low.
        target_glycogen = 1.0
        recharge_rate = 0.01 * (target_glycogen - self.glycogen)
        
        # Only recharge if we aren't under heavy load
        if self.glutamate_load < 0.5:
             self.glycogen += recharge_rate * dt

        # 4. Transport to Neurons (Feeding the brain)
        flux_astro_to_ecs = self.Vmax_MCT4 * (self.astro_lactate / (self.Km_MCT4 + self.astro_lactate + 1e-9))
        flux_ecs_to_neuron = self.Vmax_MCT2 * (self.ext_lactate / (self.Km_MCT2 + self.ext_lactate + 1e-9))

        self.astro_lactate -= flux_astro_to_ecs * dt
        self.ext_lactate += (flux_astro_to_ecs - flux_ecs_to_neuron) * dt
        self.neuron_lactate += flux_ecs_to_neuron * dt

        # 5. ATP Production (The Result)
        conversion_rate = 2.0 * self.neuron_lactate
        atp_production = conversion_rate * 3.0
        self.neuron_lactate -= conversion_rate * dt

        basal_metabolism = 0.005
        # Scaled down activity cost
        activity_cost = (basal_firing * 0.01) + (cortical_demand * 0.05)
        
        self.neuronal_atp += (atp_production - (basal_metabolism + activity_cost)) * dt

        # Decay demand signal
        self.glutamate_load *= 0.95

        # Clamp compartments
        self.glycogen = float(np.clip(self.glycogen, 0.0, 1.0))
        self.neuronal_atp = float(np.clip(self.neuronal_atp, 0.0, 1.5))

        self.astro_lactate = float(max(0.0, self.astro_lactate))
        self.ext_lactate = float(max(0.0, self.ext_lactate))
        self.neuron_lactate = float(max(0.0, self.neuron_lactate))

        return self.neuronal_atp, self.ext_lactate


class TRNGate:
    def __init__(self):
        self.sectors = np.array([-65.0, -65.0])
        self.h_gates = np.array([0.0, 0.0])
        self.modes = ["TONIC", "TONIC"]
        self.W_lat = 0.5
        self.deterministic_mode = False

    def step(self, arousal_level: float, amygdala_drive: float, pfc_attention: float, dt: float = 0.05):
        arousal_level = clamp(float(arousal_level), 0.0, 2.0)
        amygdala_drive = clamp(float(amygdala_drive), 0.0, 10.0)
        pfc_attention = clamp(float(pfc_attention), 0.0, 10.0)

        input_0 = (arousal_level * 5.0) + (amygdala_drive * 10.0)
        input_1 = (arousal_level * 5.0) + (pfc_attention * 5.0)

        inputs = np.array([input_0, input_1])
        new_potentials = np.copy(self.sectors)

        for i in range(2):
            neighbor = 1 - i
            inhibition = 0.0
            if self.sectors[neighbor] > -55.0:
                inhibition = self.W_lat * (self.sectors[neighbor] + 55.0)

            target_v = -65.0 + inputs[i] - inhibition
            if arousal_level < 0.2:
                target_v = -75.0

            tau_v = 0.25
            alpha_v = 1.0 - np.exp(-dt / tau_v)
            new_potentials[i] += (target_v - self.sectors[i]) * alpha_v
            if self.deterministic_mode:
                new_potentials[i] = float(np.round(new_potentials[i], 10))

            h_inf = 1.0 / (1.0 + np.exp((new_potentials[i] + 70.0) / 4.0))
            self.h_gates[i] += ((h_inf - self.h_gates[i]) / 20.0) * dt
            if self.deterministic_mode:
                self.h_gates[i] = float(np.round(self.h_gates[i], 10))

            if self.h_gates[i] > 0.6 and new_potentials[i] > -65.0:
                self.modes[i] = "BURST"
            elif new_potentials[i] > -65.0:
                self.modes[i] = "TONIC"

        self.sectors = new_potentials
        return self.modes


class PVLV_Learning:
    def __init__(self):
        self.w_pv = 0.0
        self.w_lv = 0.0
        self.alpha_pv = 0.1
        self.alpha_lv = 0.05

    def step(self, sensory_drive: float, reward_present: float, baseline_dopamine: float = 0.0, serotonin: float = 0.5):
        sensory_drive = float(max(0.0, sensory_drive))
        reward_present = float(max(0.0, reward_present))
        baseline_dopamine = float(clamp(baseline_dopamine, 0.0, 1.5))
        serotonin = float(clamp(serotonin, 0.0, 1.0))

        # Low serotonin devalues rewards (impatience); high serotonin preserves value
        patience_factor = 0.5 + (serotonin * 0.5)
        discounted_reward = reward_present * patience_factor

        pv_prediction = self.w_pv * sensory_drive
        pv_error = discounted_reward - pv_prediction
        self.w_pv += self.alpha_pv * pv_error * sensory_drive

        lv_prediction = self.w_lv * sensory_drive
        lv_error = pv_prediction - lv_prediction
        self.w_lv += self.alpha_lv * lv_error * sensory_drive

        phasic_dopamine = pv_error + lv_prediction
        dopamine_total = clamp(baseline_dopamine + phasic_dopamine, -1.0, 2.0)
        return float(dopamine_total), float(phasic_dopamine)


class LocusCoeruleus:
    """
    Simplified LC-NE system:
    - tonic_ne: slow background arousal/uncertainty-driven exploration (0..1)
    - phasic_ne: fast bursts to salient events (0..1)
    Produces:
      - arousal_boost: feeds TRN arousal
      - attention_gain: scales thalamic relay gain
      - explore_gain: scales motor noise / jitter -> exploration
      - plasticity_gain: scales learning/plasticity modulation
    """
    def __init__(self):
        self.tonic_ne = 0.2
        self.phasic_ne = 0.0
        self.reward_pred = 0.0  # crude expectation tracker
        self.uncertainty = 0.0
        self.mode = "EXPLOIT"
        self.last = {
            "arousal_boost": 0.0,
            "attention_gain": 1.0,
            "explore_gain": 1.0,
            "plasticity_gain": 1.0,
            "habit_weight": 1.0,
            "deliberation_weight": 1.0,
            "wm_stability": 1.0,
            "attention_breadth": 1.0,
        }

    def step(self, novelty: float, pain: float, reward: float, danger: float, dt: float = 0.05, surprise: float = 0.0):
        novelty = clamp(float(novelty), 0.0, 1.0)
        pain    = clamp(float(pain), 0.0, 1.0)
        reward  = clamp(float(reward), 0.0, 1.0)
        danger  = clamp(float(danger), 0.0, 1.0)
        pe_surprise = clamp(float(surprise), 0.0, 1.0)

        # --- 1. Uncertainty from prediction error (slow EMA of surprise) ---
        reward_surprise = abs(reward - self.reward_pred)
        self.reward_pred = ema(self.reward_pred, reward, tau=0.25, dt=dt)
        unc_input = max(reward_surprise, pe_surprise)
        self.uncertainty = ema(self.uncertainty, unc_input, tau=2.0, dt=dt)

        # --- 2. Phasic NE: fast salience bursts ---
        salience = max(novelty, pain, danger, reward_surprise, pe_surprise)
        self.phasic_ne = clamp(ema(self.phasic_ne, salience, tau=0.10, dt=dt), 0.0, 1.0)

        # --- 3. Tonic NE: uncertainty + environment ---
        target_tonic = 0.15 + (0.6 * self.uncertainty)
        target_tonic += 0.3 * novelty
        target_tonic += 0.25 * danger
        target_tonic += 0.15 * pain
        target_tonic = clamp(target_tonic, 0.0, 1.0)
        self.tonic_ne = clamp(ema(self.tonic_ne, target_tonic, tau=1.50, dt=dt), 0.0, 1.0)

        # --- 4. Mode classification ---
        if self.tonic_ne < 0.35:
            self.mode = "EXPLOIT"
        elif self.tonic_ne < 0.65:
            self.mode = "BALANCED"
        else:
            self.mode = "EXPLORE"

        # --- 5. Outputs ---
        habit_weight = clamp(1.2 - (self.tonic_ne * 1.0), 0.2, 1.2)
        deliberation_weight = clamp(0.5 + (self.tonic_ne * 1.0), 0.5, 1.5)

        if self.phasic_ne < 0.5:
            wm_stability = 1.0
        else:
            wm_stability = clamp(1.0 - (self.phasic_ne - 0.5) * 1.4, 0.3, 1.0)

        optimal_ne = 0.5
        distance_from_optimal = abs(self.tonic_ne - optimal_ne)
        attention_gain = clamp(1.5 - (distance_from_optimal * 1.0), 0.7, 1.5)
        attention_gain += self.phasic_ne * 0.4
        attention_gain = clamp(attention_gain, 0.5, 2.0)

        attention_breadth = clamp(0.3 + (self.tonic_ne * 1.2), 0.3, 1.5)
        explore_gain = clamp(0.6 + (self.tonic_ne * 1.8), 0.2, 3.0)
        plasticity_gain = clamp(0.8 + (self.phasic_ne * 1.0), 0.5, 2.0)
        arousal_boost = (0.6 * self.tonic_ne) + (1.0 * self.phasic_ne)

        self.last = {
            "arousal_boost": float(arousal_boost),
            "attention_gain": float(attention_gain),
            "explore_gain": float(explore_gain),
            "plasticity_gain": float(plasticity_gain),
            "habit_weight": float(habit_weight),
            "deliberation_weight": float(deliberation_weight),
            "wm_stability": float(wm_stability),
            "attention_breadth": float(attention_breadth),
        }
        return self.last


class VisionCortex:
    def __init__(self):
        self.ema_salience = 0.0

    def encode(self, vision_rays: List[Dict[str, Any]]) -> Dict[str, Any]:
        salience_weights = {1: 0.5, 2: 2.0, 3: 1.5} # wall, predator, target
        max_salience = 0.0
        max_target_salience = 0.0
        salient_target_ray = None

        wall_dist = 15.0
        predator_dist = 15.0
        target_dist = 15.0

        for ray in vision_rays:
            dist = ray.get("dist", 15.0)
            typ = ray.get("type", 0)
            
            if typ in salience_weights:
                salience = salience_weights[typ] * (1.0 / (dist + 1e-9))
                if salience > max_salience:
                    max_salience = salience

                if typ == 3 and salience > max_target_salience:
                    max_target_salience = salience
                    salient_target_ray = ray

            if typ == 1: wall_dist = min(wall_dist, dist)
            if typ == 2: predator_dist = min(predator_dist, dist)
            if typ == 3: target_dist = min(target_dist, dist)

        vis_vec = np.array([0.0, 0.0])
        if salient_target_ray:
            angle = salient_target_ray.get("angle", 0.0)
            vis_vec = np.array([np.cos(angle), np.sin(angle)])

        novelty = abs(max_salience - self.ema_salience)
        self.ema_salience = 0.9 * self.ema_salience + 0.1 * max_salience

        features = np.array([
            clamp(1.0 - wall_dist / 15.0, 0.0, 1.0),
            clamp(1.0 - predator_dist / 15.0, 0.0, 1.0),
            clamp(1.0 - target_dist / 15.0, 0.0, 1.0),
            clamp(novelty, 0.0, 1.0)
        ])
        
        return {
            "vis_vec": vis_vec,
            "features": features
        }

class SomatoCortex:
    def __init__(self):
        self.ema_pain = 0.0

    def encode(self, whisker_hits, collision: bool) -> Dict[str, Any]:
        touch = 1.0 if whisker_hits and any(whisker_hits) else 0.0
        pain = 1.0 if collision else 0.0
        
        self.ema_pain = max(pain, self.ema_pain * 0.9)
        
        return {
            "touch": touch,
            "pain": self.ema_pain
        }

class Thalamus:
    def __init__(self):
        self.ema_gain = 1.0

    def relay(self,
              vis: Dict[str, Any],
              som: Dict[str, Any],
              topdown_attention: float = 0.0,
              relay_gain: float = 1.0,
              noise_level: float = 0.0,
              rng=None,
              atp_level: float = 1.0,  # <--- NEW PARAMETER
              attention_breadth: float = 1.0,
              ach_precision: float = 0.0,
              ) -> Dict[str, Any]:

        # --- SEARCHLIGHT / ATTENTION BIAS ---
        # "Focus" requires both Cortex demand (attention) AND Metabolic fuel (ATP).
        # A tired brain cannot maintain top-down inhibition.
        
        # 1. Calculate Metabolic Capacity for Focus
        # If ATP drops below 0.3 (Brain Fog), focus capability collapses.
        focus_capacity = clamp((atp_level - 0.1) / 0.4, 0.0, 1.0)
        
        # 2. Determine Effective Focus
        # High Attention + High ATP = Strong Searchlight
        effective_focus = clamp(topdown_attention * focus_capacity, 0.0, 1.0)
        
        # 3. Gain Modulation (The Searchlight Beam)
        # If focused, we amplify the "Signal" (relay_gain).
        focus_gain_boost = 1.0 + (0.5 * effective_focus)
        sensory_gain = relay_gain * focus_gain_boost
        
        self.ema_gain = 0.9 * self.ema_gain + 0.1 * sensory_gain
        
        relay_vec = vis.get("vis_vec", np.array([0.0, 0.0])) * self.ema_gain
        relay_features = vis.get("features", np.array([0.0, 0.0, 0.0, 0.0])) * self.ema_gain

        # 4. Noise Inhibition (Gating Distractions)
        # A focused mind suppresses Entropy. A tired mind lets it in.
        # If effective_focus is 1.0, we block 90% of the noise.
        base_suppression = effective_focus * 0.9
        breadth_factor = clamp(2.0 - attention_breadth, 0.5, 1.0)
        noise_suppression = base_suppression * breadth_factor
        effective_noise = (noise_level * (1.0 - noise_suppression)) / (1.0 + max(0.0, ach_precision))

        # Apply the (potentially suppressed) noise
        if effective_noise > 0.01 and rng is not None:
            # Add jitter to the perceived vector
            jitter = rng.normal(0.0, 1.0, size=2) * effective_noise
            relay_vec += jitter
            
            # Add static to the features
            feat_jitter = rng.normal(0.0, 1.0, size=4) * (effective_noise * 0.5)
            relay_features = np.clip(relay_features + feat_jitter, 0.0, 1.0)

        return {
            "relay_vec": relay_vec,
            "relay_features": relay_features,
            "touch": som.get("touch", 0.0),
            "pain": som.get("pain", 0.0)
        }


class PredictiveProcessing:
    """
    Minimal predictive processing loop:
      z_{t-1} -> yhat_t
      PE_t = y_t - yhat_t
      update W using PE_t ⊗ z_{t-1}
      then compute yhat_{t+1} from z_t
    """
    def __init__(self, rng, state_dim: int, obs_dim: int = 6):
        self.rng = rng
        self.state_dim = int(state_dim)
        self.obs_dim = int(obs_dim)

        self.W = self.rng.normal(0.0, 0.05, size=(self.obs_dim, self.state_dim))
        self.b = np.zeros(self.obs_dim, dtype=float)

        self.last_z = None
        self.last_yhat = None
        self.pe_ema = 0.0

    def reset(self):
        self.last_z = None
        self.last_yhat = None
        self.pe_ema = 0.0

    def _squash01(self, x: np.ndarray) -> np.ndarray:
        return 1.0 / (1.0 + np.exp(-x))

    def predict_from(self, z: np.ndarray) -> np.ndarray:
        z = np.asarray(z, dtype=float)
        yhat = self._squash01(self.W @ z + self.b)
        return yhat

    def step(self, z_t: np.ndarray, y_t: np.ndarray, lr: float, weight_decay: float, dt: float, pe_tau: float):
        z_t = np.asarray(z_t, dtype=float)
        y_t = np.asarray(y_t, dtype=float)

        pe_vec = None
        pe_scalar = 0.0

        if self.last_z is not None:
            yhat_t = self.predict_from(self.last_z)
            pe_vec = (y_t - yhat_t)
            pe_scalar = float(np.mean(np.abs(pe_vec)))

            # Sigmoid derivative for stable local learning
            d = yhat_t * (1.0 - yhat_t)
            self.W += lr * np.outer(pe_vec * d, self.last_z)
            self.b += lr * (pe_vec * d)
            self.W *= (1.0 - weight_decay * dt)

            self.pe_ema = ema(self.pe_ema, pe_scalar, pe_tau, dt)

        yhat_next = self.predict_from(z_t)
        self.last_z = z_t
        self.last_yhat = yhat_next

        return {
            "pe_scalar": pe_scalar,
            "pe_ema": float(self.pe_ema),
            "pe_vec": pe_vec,
            "yhat_next": yhat_next,
        }


class BasalForebrain:
    """
    Simple cholinergic (ACh) model tracking expected uncertainty to modulate precision.
    """
    def __init__(self):
        self.tonic_ach = 0.2
        self.expected_uncertainty = 0.0
        self.mode = "BALANCED"
        self.last = {"precision_gain": 0.0, "mode": self.mode, "tonic_ach": self.tonic_ach}

    def step(self, pe_scalar: float, arousal: float, dt: float = 0.05):
        pe_scalar = float(clamp(pe_scalar, 0.0, 1.0))
        arousal = float(clamp(arousal, 0.0, 2.0))
        # expected uncertainty integrates PE variance (expected noise)
        self.expected_uncertainty = ema(self.expected_uncertainty, pe_scalar ** 2, tau=1.5, dt=dt)

        target_ach = 0.2 + 0.4 * clamp(arousal, 0.0, 1.5) - 0.5 * self.expected_uncertainty
        target_ach = clamp(target_ach, 0.0, 1.0)
        self.tonic_ach = ema(self.tonic_ach, target_ach, tau=1.0, dt=dt)

        self.mode = "ENCODING" if self.tonic_ach > 0.55 else ("RECALL" if self.tonic_ach < 0.35 else "BALANCED")
        precision_gain = clamp(self.tonic_ach * 2.0, 0.0, 2.0)

        self.last = {"precision_gain": precision_gain, "mode": self.mode, "tonic_ach": self.tonic_ach}
        return self.last


class PFC_Stripe:
    def __init__(self, id_):
        self.id = id_
        self.memory = np.array([0.0, 0.0])
        self.is_locked = False

    def update(self, input_vector: np.ndarray, gate_signal: float):
        if gate_signal > 0:
            self.memory = input_vector
            self.is_locked = False
        else:
            self.is_locked = True
        return self.memory


class BasalGanglia:
    def __init__(self, rng=None):
        if rng is None:
            raise ValueError("BasalGanglia requires rng injection")
        self.rng = rng
        self.reset()

    def reset(self):
        self.w_gate = self.rng.random(3)
        self.w_motor = np.ones(3)
        self.pvlv = PVLV_Learning()

    def select_action_and_gate(
        self,
        sensory_vec: np.ndarray,
        memory_vec: np.ndarray,
        drive_level: float,
        reward: float,
        learning_rate_mod: float,
        memory_gain: float = 1.0,  # <--- NEW PARAMETER
        theta_readouts: Dict[str, float] = None,
        mt_causal: bool = False,
        mt_mod_gate: float = 0.2,
        exploration_bias: float = 0.0,  # <--- NEW PARAMETER (Curiosity)
        baseline_dopamine: float = 0.0,
        serotonin: float = 0.5,
        lc_habit_weight: float = 1.0,
    ):
        sensory_mag = float(np.linalg.norm(sensory_vec))
        dopamine_total, dopamine_phasic = self.pvlv.step(
            sensory_mag,
            reward,
            baseline_dopamine=baseline_dopamine,
            serotonin=serotonin,
        )

        # Apply the manual slider gain to the memory vector
        effective_memory = memory_vec * memory_gain 

        context = np.array([np.linalg.norm(sensory_vec), np.linalg.norm(effective_memory), drive_level], dtype=float)

        gate_activation = float(np.dot(self.w_gate, context) + dopamine_total)
        
        thr = 0.5
        if mt_causal and theta_readouts:
            thr = 0.5 + mt_mod_gate * (theta_readouts["entropy"] - theta_readouts["coherence"]) * 0.1
            thr = clamp(thr, 0.4, 0.6)

        gate_signal = 1.0 if gate_activation > thr else -1.0

        serotonin_clamped = clamp(float(serotonin), 0.0, 1.0)
        sensory_bias = 1.0 - serotonin_clamped * 0.3
        memory_bias = 0.5 + serotonin_clamped * 0.5
        compulsivity = 1.0 + (1.0 - serotonin_clamped) * 0.8

        w_sensory = self.w_motor[0] * (1.0 + dopamine_total) * sensory_bias * lc_habit_weight * compulsivity
        w_memory = self.w_motor[1] * (1.0 - dopamine_total) * memory_bias * lc_habit_weight * compulsivity
        
        # Use effective_memory here
        motor_out = (sensory_vec * w_sensory) + (effective_memory * w_memory)

        # --- ENTROPY-DRIVEN EXPLORATION ---
        # If Exploration Bias (Entropy) is high, we ignore the weights and jitter.
        if exploration_bias > 0.01:
            # Generate random curiosity vector
            curiosity_vec = self.rng.normal(0.0, 1.0, size=2)
            
            # Blend it in. High bias = High randomness.
            # If bias is 1.0, the rat is purely hallucinating actions.
            motor_out = (motor_out * (1.0 - exploration_bias)) + (curiosity_vec * exploration_bias * 2.0)

        if learning_rate_mod > 0.1:
            lr = 0.01 * learning_rate_mod
            self.w_gate += lr * dopamine_total * context
            self.w_motor += lr * dopamine_total

            self.w_gate = np.clip(self.w_gate, -1.0, 1.0)
            self.w_motor = np.clip(self.w_motor, 0.0, 5.0)

        return motor_out, gate_signal, dopamine_total, thr, dopamine_phasic


class TimeCellPopulation:
    def __init__(self, n_cells=20):
        self.n_cells = n_cells
        self.cells = np.zeros(n_cells)
        self.peaks = np.linspace(0, 100, n_cells)
        self.sigmas = np.linspace(5, 20, n_cells)
        self.timer = 0
        self.active = False

    def reset(self):
        self.timer = 0
        self.active = True
        self.cells.fill(0.0)

    def step(self):
        if not self.active:
            return np.zeros(self.n_cells)

        self.timer += 1
        for i in range(self.n_cells):
            self.cells[i] = np.exp(-((self.timer - self.peaks[i]) ** 2) / (2 * self.sigmas[i] ** 2))
        return self.cells


class ReplayBuffer:
    def __init__(self, capacity: int = 240, py_rng=None):
        self.capacity = int(max(10, capacity))
        self.buf = deque(maxlen=self.capacity)
        if py_rng is None:
            raise ValueError("ReplayBuffer requires a seeded random.Random instance")
        self.py_rng = py_rng

    def set_capacity(self, capacity: int):
        capacity = int(max(10, capacity))
        if capacity == self.capacity:
            return
        old = list(self.buf)
        self.capacity = capacity
        self.buf = deque(old[-capacity:], maxlen=capacity)

    def push(self, item: Dict[str, Any]):
        self.buf.append(item)

    def __len__(self):
        return len(self.buf)

    def sample_recent(self, k: int) -> List[Dict[str, Any]]:
        k = int(max(0, min(k, len(self.buf))))
        if k == 0:
            return []
        return list(self.buf)[-k:]

    def sample_older(self) -> Optional[Dict[str, Any]]:
        if len(self.buf) < 8:
            return None
        cutoff = int(len(self.buf) * 0.25)
        pool = list(self.buf)[: max(1, len(self.buf) - cutoff)]
        return self.py_rng.choice(pool) if pool else None


class HippocampalReplay:
    """
    Runs only during offline states (microsleep).
    Replays recent snapshots; sometimes "bridges" with an older snapshot to link events.
    """
    def __init__(self, capacity: int = 240, py_rng=None):
        if py_rng is None:
            raise ValueError("HippocampalReplay requires a seeded random.Random instance")
        self.py_rng = py_rng
        self.buffer = ReplayBuffer(capacity, py_rng=self.py_rng)
        self.last_replay_trace: List[List[float]] = []

    def set_capacity(self, capacity: int):
        self.buffer.set_capacity(capacity)

    def record(
        self,
        rat_pos: np.ndarray,
        sensory_vec: np.ndarray,
        memory_vec: np.ndarray,
        frustration: float,
        reward_signal: float,
        danger_level: float,
        near_death: bool = False,
    ):
        self.buffer.push(
            {
                "pos": rat_pos.astype(float).tolist(),
                "sens": sensory_vec.astype(float).tolist(),
                "mem": memory_vec.astype(float).tolist(),
                "fr": float(frustration),
                "r": float(reward_signal),
                "danger": float(danger_level),
                "near_death": bool(near_death),
            }
        )

    def run(self, steps: int, bridge_prob: float) -> List[Dict[str, Any]]:
        self.last_replay_trace = []
        recent = self.buffer.sample_recent(steps)
        if not recent:
            return []

        out = []
        for snap in recent:
            a = snap
            b = None
            if self.py_rng.random() < bridge_prob:
                b = self.buffer.sample_older()

            base_salience_a = abs(a["r"]) + a["danger"] + 0.25 * a["fr"]
            if a.get("near_death", False):
                base_salience_a *= 1.5

            if b is None:
                sens = np.array(a["sens"], dtype=float)
                mem = np.array(a["mem"], dtype=float)
                salience = base_salience_a
                pos = a["pos"]
            else:
                base_salience_b = abs(b["r"]) + b["danger"] + 0.25 * b["fr"]
                if b.get("near_death", False):
                    base_salience_b *= 1.5
                sens = 0.6 * np.array(a["sens"], dtype=float) + 0.4 * np.array(b["sens"], dtype=float)
                mem = 0.6 * np.array(a["mem"], dtype=float) + 0.4 * np.array(b["mem"], dtype=float)
                salience = 0.5 * (base_salience_a + base_salience_b)
                pos = a["pos"]

            out.append({"sens": sens, "mem": mem, "salience": float(salience), "pos": pos})
            self.last_replay_trace.append(pos)
        return out



class PlaceCellNetwork:
    def __init__(self, n_cells: int, sigma: float, map_size: int):
        self.n_cells = n_cells
        self.sigma = sigma
        self.centers = self._create_centers(map_size)
        self.acts = np.zeros(self.n_cells)
        self.goal_vec_w = np.zeros((self.n_cells, 2))

    def _create_centers(self, map_size: int):
        """Creates a grid of place cell centers."""
        n_side = int(math.ceil(np.sqrt(self.n_cells)))
        # avoid walls; map coords are [0..map_size-1]
        xs = np.linspace(1.0, map_size - 2.0, n_side)
        ys = np.linspace(1.0, map_size - 2.0, n_side)
        xv, yv = np.meshgrid(xs, ys)
        centers = np.stack([xv.ravel(), yv.ravel()], axis=1)
        return centers[: self.n_cells]

    def step(self, pos: np.ndarray, reward: float, target_pos: np.ndarray, threshold: float, lr: float, decay: float):
        # 1. Compute activations
        dists_sq = np.sum((pos - self.centers) ** 2, axis=1)
        self.acts = np.exp(-dists_sq / (2 * self.sigma ** 2))

        # 2. Update weights if rewarded
        if reward >= threshold:
            desired = target_pos - pos
            norm = np.linalg.norm(desired)
            if norm > 0:
                desired /= norm

            current_nav_vec = self.acts @ self.goal_vec_w
            
            # Vector delta rule
            delta_w = lr * np.outer(self.acts, desired - current_nav_vec)
            self.goal_vec_w += delta_w

        # 3. Apply decay
        self.goal_vec_w *= (1 - decay)

        # 4. Clamp weights
        self.goal_vec_w = np.clip(self.goal_vec_w, -2.0, 2.0)

        # 5. Compute navigation vector
        nav_vec = self.acts @ self.goal_vec_w
        norm = np.linalg.norm(nav_vec)
        if norm > 1e-9:
            nav_vec /= norm
        else:
            nav_vec = np.array([0.0, 0.0])
        
        return self.acts, nav_vec

    def reset(self):
        self.acts.fill(0.0)
        self.goal_vec_w.fill(0.0)


class DendriticCluster:
    def __init__(self, config: Dict[str, Any] = None, rng=None, py_rng=None, mt_rng=None, load_genome: bool = True, preserve_weights: Dict = None):
        if rng is None:
            raise ValueError("DendriticCluster requires rng injection")
        if py_rng is None:
            raise ValueError("DendriticCluster requires py_rng injection")
        if mt_rng is None:
            raise ValueError("DendriticCluster requires mt_rng injection")
        self.rng = rng
        self.py_rng = py_rng
        self.mt_rng = mt_rng
        self.config = config or {}
        
        # --- COMPONENT FACTORY ---
        mt_type = self.config.get("coherence_field_type", "microtubule")
        
        if mt_type == "noise":
            FieldClass = OUNoiseField
            print("BRAIN: Using Null Hypothesis (OUNoiseField)")
        else:
            FieldClass = MicrotubuleSimulator2D
            print("BRAIN: Using Standard Model (MicrotubuleSimulator2D)")

        # Instantiate Soma
        self.soma = FieldClass("Executive Soma", length_points=32, rng=self.mt_rng)
        
        # Instantiate Theta (can use same type or be distinct)
        self.mt_theta = FieldClass("Theta Memory", length_points=32, rng=self.mt_rng)
        if hasattr(self.mt_theta, "H_BAR"): self.mt_theta.H_BAR = 6.0 # Only for quantum

        self.pfc = PFC_Stripe(0)
        self.basal_ganglia = BasalGanglia(rng=self.rng)

        self.astrocyte = Astrocyte()
        self.trn = TRNGate()
        self.bf = BasalForebrain()
        self.time_cells = TimeCellPopulation()
        self.lc = LocusCoeruleus()
        self.orchestrator = BrainOrchestrator(self.config, self.rng)
        self.orchestrator.register(VisionCortexComponent())
        self.orchestrator.register(SomatoCortexComponent())
        self.orchestrator.register(LocusCoeruleusComponent())
        self.orchestrator.register(BasalForebrainComponent())
        self.orchestrator.register(BasalGangliaComponent(self.rng))

        self.thalamus = Thalamus()
        self.place_cells = None

        self.mt_readout_soma = 0.0 # New
        self.mt_readout_theta = 0.0 # New

        # Predictive Processing (PP)
        self.pp_state_dim = 12
        self.pp = PredictiveProcessing(rng=self.rng, state_dim=self.pp_state_dim, obs_dim=6)
        self.last_pp = {"pe_norm": 0.0, "pe_ema": 0.0, "yhat_next": np.zeros(6)}
        self.last_bf = {"precision_gain": 0.0, "mode": "BALANCED", "tonic_ach": 0.2}

        # Working Memory bank (thalamic/PFC-gated slots)
        self.wm_slots_n = 5
        self.wm_dim = 16
        self.wm_slots = [{"v": np.zeros(self.wm_dim), "strength": 0.0, "age": 0, "tag": 0} for _ in range(self.wm_slots_n)]
        self.last_wm_bias = np.zeros(2)
        self.wm_write_threshold = 0.2
        self.wm_decay_rate = 0.02
        self.wm_motor_gain = 1.0

        # STC variables
        self.synaptic_tags = np.zeros(3)
        self.prp_level = 0.0

        # Theta / Grid / HD
        self.grid_k = [
            np.array([np.cos(0), np.sin(0)]),
            np.array([np.cos(np.pi / 3), np.sin(np.pi / 3)]),
            np.array([np.cos(2 * np.pi / 3), np.sin(2 * np.pi / 3)]),
        ]
        self.pos_hat = None
        self.grid_phases = np.array([0.0, 0.0, 0.0])
        self.grid_scale = 0.8

        self.hd_cell_count = 36
        self.hd_cells = self._create_activity_bump(self.hd_cell_count, 0)
        self.hd_integration_weight = 2.0
        self.replay = HippocampalReplay(capacity=240, py_rng=self.py_rng)

        self.place_memories: List[np.ndarray] = []

        # Evolution weights (used below)
        self.weights = {"amygdala": 1.0, "striatum": 1.0, "hippocampus": 1.0}
        if load_genome:
            self.load_latest_memory()

        if preserve_weights:
            self.basal_ganglia.w_gate = preserve_weights["w_gate"]
            self.basal_ganglia.w_motor = preserve_weights["w_motor"]
            self.weights = preserve_weights["genome"]

    def _create_activity_bump(self, size, position):
        x = np.arange(size)
        bump = np.exp(-0.5 * np.minimum((x - position) ** 2, (size - np.abs(x - position)) ** 2) / (size / 10) ** 2)
        return bump / np.sum(bump)

    def _reset_wm(self):
        self.wm_slots = [{"v": np.zeros(self.wm_dim), "strength": 0.0, "age": 0, "tag": 0} for _ in range(self.wm_slots_n)]
        self.last_wm_bias = np.zeros(2)

    def _build_wm_candidate(
        self,
        rat_pos: np.ndarray,
        rat_vel: np.ndarray,
        head_direction: float,
        target_pos: Optional[np.ndarray],
        frustration: float,
        dopamine_tonic: float,
        danger_level: float,
        panic: float,
        novelty: float,
        pain: float,
        touch: float,
        pheromones_len: int,
        map_size: int,
    ) -> np.ndarray:
        vec = np.zeros(self.wm_dim, dtype=float)
        ms = max(float(map_size), 1.0)
        pos_norm = np.array([rat_pos[0] / ms, rat_pos[1] / ms], dtype=float)
        vec[0:2] = pos_norm  # Where am I?

        # Directional cues
        vec[2] = float(np.sin(head_direction))
        vec[3] = float(np.cos(head_direction))
        vec[4:6] = np.array(rat_vel, dtype=float)

        targ_dir = np.array([0.0, 0.0])
        if target_pos is not None:
            diff = np.array(target_pos, dtype=float) - np.array(rat_pos, dtype=float)
            norm = float(np.linalg.norm(diff))
            if norm > 1e-6:
                targ_dir = diff / norm
        vec[6:8] = targ_dir

        vec[8] = float(frustration)
        vec[9] = float(dopamine_tonic)
        vec[10] = float(danger_level)
        vec[11] = float(panic)
        vec[12] = float(novelty)
        vec[13] = float(pain)
        vec[14] = float(touch)
        vec[15] = float(min(1.0, pheromones_len / 50.0))
        return vec

    def _wm_decay_slots(self, dt: float):
        decay = max(0.0, 1.0 - self.wm_decay_rate * dt)
        for slot in self.wm_slots:
            slot["strength"] *= decay
            slot["age"] += 1
            if slot["strength"] < 1e-3:
                slot["v"].fill(0.0)
                slot["strength"] = 0.0
                slot["tag"] = 0

    def _wm_retrieve(self, candidate: np.ndarray):
        best_idx = None
        best_score = -1.0
        cand_norm = float(np.linalg.norm(candidate)) + 1e-9
        for idx, slot in enumerate(self.wm_slots):
            if slot["strength"] <= 0.0:
                continue
            slot_norm = float(np.linalg.norm(slot["v"])) + 1e-9
            sim = float(np.dot(candidate, slot["v"]) / (cand_norm * slot_norm))
            sim *= (0.5 + 0.5 * slot["strength"])
            if sim > best_score:
                best_score = sim
                best_idx = idx
        return best_idx, best_score

    def _wm_write(self, candidate: np.ndarray, drive: float):
        if drive <= self.wm_write_threshold:
            return
        strengths = [slot["strength"] for slot in self.wm_slots]
        target_idx = int(np.argmin(strengths))
        slot = self.wm_slots[target_idx]
        slot["v"] = candidate.copy()
        slot["strength"] = clamp(drive, 0.0, 1.0)
        slot["age"] = 0
        slot["tag"] = 1 if drive > 0.8 else 0

    def update_hd_cells(self, angular_velocity):
        shift = -angular_velocity * self.hd_integration_weight * self.hd_cell_count / (2 * np.pi)
        f_hd = np.fft.fft(self.hd_cells)
        freqs = np.fft.fftfreq(self.hd_cell_count)
        f_hd *= np.exp(-1j * 2 * np.pi * freqs * shift)
        self.hd_cells = np.real(np.fft.ifft(f_hd))
        self.hd_cells += 0.01 * self._create_activity_bump(self.hd_cell_count, np.argmax(self.hd_cells))
        self.hd_cells /= np.sum(self.hd_cells)

    def get_head_direction(self):
        return np.argmax(self.hd_cells) * (2 * np.pi / self.hd_cell_count)

    def update_grid_cells(self, velocity, head_direction):
        rotation_matrix = np.array(
            [[np.cos(head_direction), -np.sin(head_direction)], [np.sin(head_direction), np.cos(head_direction)]]
        )
        for i in range(3):
            rotated_k = rotation_matrix @ self.grid_k[i]
            proj = float(np.dot(velocity, rotated_k))
            drift = float(self.rng.normal(0, 0.001))
            self.grid_phases[i] += (proj * self.grid_scale) + drift
            self.grid_phases[i] %= (2 * np.pi)

    def get_grid_visualization(self):
        size = 32
        x = np.linspace(-np.pi, np.pi, size)
        y = np.linspace(-np.pi, np.pi, size)
        X, Y = np.meshgrid(x, y)
        W1 = np.cos(X * np.cos(0) + Y * np.sin(0) + self.grid_phases[0])
        W2 = np.cos(X * np.cos(np.pi / 3) + Y * np.sin(np.pi / 3) + self.grid_phases[1])
        W3 = np.cos(X * np.cos(2 * np.pi / 3) + Y * np.sin(2 * np.pi / 3) + self.grid_phases[2])
        return (W1 + W2 + W3 + 3) / 6.0

    def load_latest_memory(self):
        if "sim" in globals() and getattr(sim, "config", {}).get("deterministic", 0.0) > 0.5:
            return
        if os.path.exists("evolution_log.csv"):
            try:
                with open("evolution_log.csv", "r") as f:
                    lines = f.readlines()
                    if len(lines) > 1:
                        last_line = lines[-1].strip().split(",")
                        self.weights["amygdala"] = float(last_line[2])
                        self.weights["striatum"] = float(last_line[3])
                        self.weights["hippocampus"] = float(last_line[4])
            except Exception:
                pass

    def save_memory(self):
        if "sim" in globals() and getattr(sim, "config", {}).get("deterministic", 0.0) > 0.5:
            return
        with open("brain_genome.json", "w") as f:
            json.dump(self.weights, f)

    def update_stc(self, activity_vector, reward_signal, dt=0.05):
        tag_tau = 2.0
        prp_tau = 5.0
        tag_decay = np.exp(-dt / tag_tau)
        prp_decay = np.exp(-dt / prp_tau)

        self.synaptic_tags *= tag_decay
        self.synaptic_tags += 0.1 * np.abs(activity_vector)
        self.synaptic_tags = np.clip(self.synaptic_tags, 0.0, 1.0)

        if reward_signal > 0.5:
            self.prp_level = 1.0
        else:
            self.prp_level *= prp_decay

        consolidation = self.synaptic_tags * self.prp_level
        return consolidation

    def record_experience(
        self,
        rat_pos,
        sensory_vec,
        current_memory,
        frustration,
        reward_signal,
        danger_level,
        replay_len: int,
        near_death: bool = False,
    ):
        self.replay.set_capacity(replay_len)
        self.replay.record(
            rat_pos=np.array(rat_pos, dtype=float),
            sensory_vec=sensory_vec,
            memory_vec=current_memory,
            frustration=frustration,
            reward_signal=reward_signal,
            danger_level=danger_level,
            near_death=near_death,
        )

    def offline_replay_and_consolidate(self, steps: int, bridge_prob: float, strength: float, stress_learning_gain: float = 0.5):
        """
        Quantum Replay:
        1. Inject memory buffer into Microtubule Field (Dreaming).
        2. Check for Coherence (Finding a 'Simple Rule').
        3. If Coherent -> Consolidate to BG & Wipe Hippocampus (Collapse).
        4. If Entropic -> Do nothing (Keep memories for later).
        """
        items = self.replay.run(steps=steps, bridge_prob=bridge_prob)
        if not items:
            return

        # 1. The "Dream": Pump Microtubules with Memory Data
        # Calculate a composite "Memory Vector" from the replay batch to simulate the "gist"
        avg_mem_vec = np.mean([it["mem"] for it in items], axis=0)
        pump_strength = float(np.linalg.norm(avg_mem_vec))
        
        # Pump the Theta field to see if it "Harmonizes" (finds coherence)
        # We do a quick burst of steps to simulate "Search for Rule"
        coherence_sum = 0.0
        for _ in range(3): 
            # Create a pump map derived from the memory intensity
            pump_map = np.ones((self.mt_theta.Ny, self.mt_theta.Nx)) * pump_strength * 0.5
            self.mt_theta.step(pump_map)
            coherence_sum += self.mt_theta.avg_coherence
        
        avg_coherence = coherence_sum / 3.0

        # 2. Quantum Collapse Decision
        # Threshold: If Coherence > 0.4, we have found a low-entropy explanation for the data.
        if avg_coherence > 0.4:
            
            # Boost Consolidation Strength (The Rule is Valid)
            # High Coherence = Stronger hard-coding into habits
            consolidation_strength = strength * (1.0 + avg_coherence * 2.0)
            
            for it in items:
                sens = it["sens"]
                mem = it["mem"]
                activity_proxy = np.array([np.linalg.norm(sens), np.linalg.norm(mem), 1.0], dtype=float)

                prp_like = 1.0 if it["salience"] > 0.8 else 0.0
                consolidation_vec = self.update_stc(activity_proxy, prp_like)

                if float(np.max(consolidation_vec)) > 0.1:
                    scale = 1.0 + stress_learning_gain * clamp(float(it["salience"]), 0.0, 2.0)
                    # Apply to Basal Ganglia (Long Term Storage)
                    self.basal_ganglia.w_gate += (0.001 * consolidation_strength * scale) * consolidation_vec
                    self.basal_ganglia.w_gate = np.clip(self.basal_ganglia.w_gate, -1.0, 1.0)

            # 3. The "Collapse": Wiping Clean
            # The complex possibilities have collapsed into a simple weight update.
            # Reset the MT field (Entropy Drop)
            self.mt_theta.reset_wavefunction()
            
            # "Wipe Clean" the Hippocampus (Buffer Clear)
            # The rat has "slept on it" and learned. It is now ready for a new "Day".
            self.replay.buffer.buf.clear()

    def process_votes(
        self,
        frustration,
        dopamine_tonic,
        rat_vel,
        reward_signal,
        danger_level,
        pheromones_len,
        head_direction,
        vision_data,
        anesthetic_level=0.0,
        # --- NEW PARAMETERS ---
        fear_gain=1.0,
        memory_gain=1.0,
        energy_constraint=True,
        # NEW OPTIONAL SENSORY INPUTS (backwards compatible)
        whisker_hits=None,
        collision=False,
        sensory_blend=0.0,
        enable_sensory_cortex=False,
        enable_thalamus=False,
        extra_arousal=0.0,
        rat_pos=None,
        panic: float = 0.0,
        cortisol: float = 0.0,
        near_death: bool = False,
        panic_trn_gain: float = 0.5,
        replay_len: int = 240,
        dt: float = 0.05,
        precomputed_trn_modes: Optional[List[str]] = None,
        arousal: float = 0.0,
        amygdala_drive: float = 0.0,
        pfc_drive: float = 0.0,
        target_pos: Optional[np.ndarray] = None,
        config: Dict[str, Any] = None,
        map_size: int = 40,
        predator_pos=None,
        serotonin: float = 0.5,
    ):
        if config is None:
            config = {}
        sim_predator_pos = np.array(predator_pos) if predator_pos is not None else np.array([0.0, 0.0])
        rat_pos_arr = np.array(rat_pos, dtype=float) if rat_pos is not None else np.array([0.0, 0.0])
        # ---- Apply genome weights so evolution actually matters ----
        w_amyg = clamp(self.weights.get("amygdala", 1.0), 0.1, 10.0)
        w_str  = clamp(self.weights.get("striatum", 1.0), 0.1, 10.0)
        w_hip  = clamp(self.weights.get("hippocampus", 1.0), 0.1, 10.0)

        self.update_grid_cells(rat_vel, head_direction)

        neural_activity = float(np.linalg.norm(rat_vel) + frustration)
        
        # --- METABOLIC COST OF THOUGHT ---
        # 1. Check current energy reserves BEFORE spending them
        current_atp = self.astrocyte.neuronal_atp
        
        # 2. Define thresholds
        # If ATP < 0.3, we enter "Brain Fog" (Metabolic Conservation)
        cognitive_threshold = 0.3 
        
        cortical_gain = 1.0
        cortical_load = 1.0 # We intend to think hard
        
        if energy_constraint and current_atp < cognitive_threshold:
            # METABOLIC CRASH:
            # The brain cannot afford to run the Cortex/PFC.
            # 1. Shut down cortical gain (Logic reverts to Basal Ganglia reflexes)
            cortical_gain = 0.1 
            # 2. Reduce the metabolic load passed to the Astrocyte (we stopped thinking)
            cortical_load = 0.1 
            # 3. Hinder attention
            pfc_drive *= 0.1

        # 3. Run the Astrocyte Step with split costs
        real_atp, ext_lactate = self.astrocyte.step(
            basal_firing=neural_activity, 
            cortical_load=cortical_load, 
            dt=dt
        )

        if energy_constraint:
            atp_availability = real_atp
        else:
            atp_availability = 1.0 

        if reward_signal > 0:
            self.time_cells.reset()
        _temporal_context = self.time_cells.step() 

        # --- ORCHESTRATOR SENSORY INJECTION ---
        # We pass raw environmental data directly to the brain.
        # The new Vision/Somato components will process this into 'novelty', 'pain', etc.

        surprise_for_lc = 0.0
        if config.get("enable_predictive_processing", 0.0) > 0.5:
            surprise_for_lc = float(self.last_pp.get("pe_norm", 0.0)) * float(config.get("pp_surprise_gain", 1.0))

        # --- ORCHESTRATOR STEP (CENTRAL UPDATE) ---
        orchestrator_inputs = {
            "vision_buffer": vision_data,
            "whisker_hits": whisker_hits,
            "collision": collision,
            "surprise": surprise_for_lc,
            "danger": float(danger_level),
        }

        # Inject cognitive state needed by downstream components
        self.orchestrator.cognitive.working_memory = self.pfc.memory.copy()
        self.orchestrator.cognitive.frustration = float(frustration)

        # Run the Pipeline (Sensory -> Neuromodulators -> BG)
        self.orchestrator.step(dt, orchestrator_inputs, float(1.0 if reward_signal > 0 else 0.0))

        # --- EXTRACT BUS DATA (Make variables available for legacy logic) ---
        bus_sensory = self.orchestrator.sensory
        bus_neuromod = self.orchestrator.neuromod
        
        # 1. Sensory Primitives
        novelty = float(bus_sensory.novelty)
        pain = float(bus_sensory.pain)
        touch = float(bus_sensory.touch)
        
        # 2. Legacy Data Structures (for Thalamus/TRN compatibility)
        vis_data = {
            "vis_vec": bus_sensory.vision_vec,
            "features": bus_sensory.vision_features
        }
        som_data = {
            "touch": touch,
            "pain": pain
        }

        # 3. Neuromodulator Output Dictionary (lc_out)
        lc_out = {
            "arousal_boost": bus_neuromod.arousal_boost,
            "attention_gain": bus_neuromod.attention_gain,
            "explore_gain": bus_neuromod.explore_gain,
            "plasticity_gain": bus_neuromod.plasticity_gain,
            "habit_weight": bus_neuromod.habit_weight,
            "deliberation_weight": bus_neuromod.deliberation_weight,
            "wm_stability": bus_neuromod.wm_stability,
            "attention_breadth": bus_neuromod.attention_breadth,
        }

        # 4. Basal Forebrain State
        self.last_bf = {
            "tonic_ach": bus_neuromod.acetylcholine,
            "precision_gain": bus_neuromod.ach_precision_gain,
            "mode": bus_neuromod.ach_mode
        }
        
        # 5. Define Vectors for downstream blending
        sensory_vec_old_raw = np.array(bus_sensory.vision_vec, dtype=float)
        sensory_vec_new_raw = np.array(bus_sensory.vision_vec, dtype=float)

        # --- EXTRACT BG OUTPUTS ---
        bg_heading = self.orchestrator.motor.heading_vec
        bg_gate = self.orchestrator.cognitive.gate_signal
        internal_dopamine_phasic = self.orchestrator.neuromod.dopamine_phasic

        # Overwrite legacy outputs
        final_vector = bg_heading
        gate_signal = bg_gate
        internal_dopamine_total = dopamine_tonic + internal_dopamine_phasic
        mt_gate_thr = 0.5  # placeholder for compatibility

        if precomputed_trn_modes is not None:
            trn_modes = precomputed_trn_modes
        else:
            trn_modes = self.trn.step(arousal, amygdala_drive, pfc_drive, dt=dt)

        gain_sensory = 1.0 if trn_modes[0] == "TONIC" else 0.05
        gain_memory = 1.0 if trn_modes[1] == "TONIC" else 0.05

        gain_sensory *= (1.0 - panic_trn_gain * min(panic, 1.0) * 0.2)
        gain_memory *= (1.0 - panic_trn_gain * min(panic, 1.0) * 0.1)
        gain_sensory = max(0.05, gain_sensory)
        gain_memory = max(0.05, gain_memory)

        theta_r_prev = self.mt_theta.get_readouts()

        # --- ENTROPY vs COHERENCE LOGIC ---
        # "Curiosity" is defined as the gap between Entropy (Confusion) and Coherence (Understanding).
        # Range: 0.0 (Lucid) to 1.0 (Totally Confused)
        
        epistemic_entropy = theta_r_prev.get("entropy", 0.0)
        coherence = theta_r_prev.get("coherence", 1.0)
        
        # Calculate the delta
        confusion_index = clamp(epistemic_entropy - coherence, 0.0, 1.0)
        
        # Scale for specific subsystems
        # Thalamus gets mild noise (distortion)
        thalamic_noise = confusion_index * 0.3 
        
        # Basal Ganglia gets exploration bias (jitter)
        # We assume if 'mt_causal' is True, we let this drive behavior.
        bg_exploration = 0.0
        if config.get("mt_causal", 0.0) > 0.5:
            # Amplify the effect so it's visible
            bg_exploration = confusion_index * config.get("mt_mod_explore", 0.5)

        sensory_vec_old_gated = sensory_vec_old_raw * gain_sensory
        sensory_vec_new_gated = np.array([0.0, 0.0])

        if enable_sensory_cortex and sensory_vec_new_raw is not None:
            if enable_thalamus:
                thalamus_out = self.thalamus.relay(
                    vis_data, 
                    som_data, 
                    topdown_attention=pfc_drive, 
                    relay_gain=gain_sensory * lc_out["attention_gain"],
                    # NEW ARGS:
                    noise_level=thalamic_noise,
                    rng=self.rng,
                    # NEW ARG:
                    atp_level=self.astrocyte.neuronal_atp,
                    attention_breadth=lc_out.get("attention_breadth", 1.0),
                    ach_precision=self.last_bf.get("precision_gain", 0.0),
                )
                sensory_vec_new_gated = thalamus_out["relay_vec"]
            else:
                sensory_vec_new_gated = sensory_vec_new_raw * gain_sensory

        # Observation vector for predictive processing: [features(4), pain, touch]
        obs_feat = np.zeros(4, dtype=float)
        obs_pain = float(pain)
        obs_touch = float(touch)
        if enable_sensory_cortex:
            if enable_thalamus and "relay_features" in thalamus_out:
                obs_feat = np.array(thalamus_out.get("relay_features", obs_feat), dtype=float)
                obs_pain = float(thalamus_out.get("pain", obs_pain))
                obs_touch = float(thalamus_out.get("touch", obs_touch))
            elif vis_data is not None:
                obs_feat = np.array(vis_data.get("features", obs_feat), dtype=float)
        y_t = np.clip(np.concatenate([obs_feat, [obs_pain, obs_touch]]), 0.0, 1.0)

        # 3. Blend the two gated vectors
        k = clamp(float(sensory_blend), 0.0, 1.0)
        sensory_vec = ((1 - k) * sensory_vec_old_gated) + (k * sensory_vec_new_gated)

        # --- WORKING MEMORY (slot bank) ---
        self._wm_decay_slots(dt)
        wm_candidate = self._build_wm_candidate(
            rat_pos=rat_pos_arr,
            rat_vel=np.array(rat_vel, dtype=float),
            head_direction=head_direction,
            target_pos=target_pos,
            frustration=frustration,
            dopamine_tonic=dopamine_tonic,
            danger_level=danger_level,
            panic=panic,
            novelty=novelty,
            pain=pain,
            touch=touch,
            pheromones_len=int(pheromones_len),
            map_size=int(map_size),
        )
        wm_bias_vec = np.zeros(2)
        wm_best_strength = 0.0
        best_idx, best_score = self._wm_retrieve(wm_candidate)
        if best_idx is not None and best_score > 0:
            slot = self.wm_slots[best_idx]
            wm_best_strength = slot["strength"]
            wm_bias_vec = slot["v"][:2] * slot["strength"]
            slot["strength"] = clamp(slot["strength"] + 0.05, 0.0, 1.0)
        self.last_wm_bias = wm_bias_vec

        # --- INTERNAL PATH INTEGRATION (GRID/HD CAUSAL LOOP) ---
        if self.pos_hat is None and rat_pos is not None:
            self.pos_hat = np.array(rat_pos, dtype=float)

        if self.pos_hat is not None:
            base_dt = float(config.get("dt", 0.05))
            dt_scale = dt / max(base_dt, 1e-6)
            self.pos_hat = self.pos_hat + np.array(rat_vel, dtype=float) * dt_scale

            if config.get("mt_causal", 0.0) > 0.5:
                drift = (theta_r_prev["entropy"] - theta_r_prev["coherence"]) * 0.02
                self.pos_hat += self.rng.normal(0.0, abs(drift), size=2)

            self.pos_hat[0] = clamp(self.pos_hat[0], 1.0, map_size - 2.0)
            self.pos_hat[1] = clamp(self.pos_hat[1], 1.0, map_size - 2.0)

        # --- PLACE CELL NAVIGATION ---
        place_metrics = {
            "place_nav_mag": 0.0,
            "place_act_max": 0.0,
            "place_goal_strength": 0.0
        }
        if self.place_cells and rat_pos is not None and target_pos is not None:
            pos_for_place = self.pos_hat if self.pos_hat is not None else rat_pos
            place_acts, place_nav_vec = self.place_cells.step(
                pos=pos_for_place,
                reward=reward_signal,
                target_pos=target_pos,
                threshold=config.get("goal_reward_threshold", 0.5),
                lr=config.get("place_goal_lr", 0.02),
                decay=config.get("place_decay", 0.001)
            )
            
            place_nav_mag = float(np.linalg.norm(place_nav_vec))
            if place_nav_mag > 0:
                place_nav_vec = place_nav_vec / place_nav_mag  # keep navigation direction unit-length

            base_gain = float(config.get("place_nav_gain", 1.0))
            lc_delib_boost = float(lc_out.get("deliberation_weight", 1.0)) if lc_out else 1.0
            gain = base_gain * lc_delib_boost
            sensory_vec = sensory_vec + (gain * place_nav_vec * gain_sensory)

            # Soft clamp magnitude to preserve LC/TRN gating meaning
            mag = float(np.linalg.norm(sensory_vec))
            if mag > 3.0:
                sensory_vec *= (3.0 / (mag + 1e-9))

            place_metrics["place_nav_mag"] = place_nav_mag
            place_metrics["place_act_max"] = float(np.max(place_acts))
            place_metrics["place_goal_strength"] = float(np.mean(np.abs(self.place_cells.goal_vec_w)))

        # Apply the metabolic limit to working memory and LC stability (phasic NE wipes WM)
        wm_stability = float(lc_out.get("wm_stability", 1.0)) if lc_out else 1.0
        current_memory = self.pfc.memory * gain_memory * cortical_gain * wm_stability
        if wm_best_strength > 0:
            current_memory = np.clip(current_memory + (wm_bias_vec * self.wm_motor_gain), -3.0, 3.0)

        # --- PREDICTIVE PROCESSING UPDATE ---
        if config.get("enable_predictive_processing", 0.0) > 0.5:
            hd_sin = float(np.sin(head_direction))
            hd_cos = float(np.cos(head_direction))
            theta_entropy = float(theta_r_prev.get("entropy", 0.0))
            theta_coh = float(theta_r_prev.get("coherence", 1.0))
            z_t = np.array([
                float(current_memory[0]), float(current_memory[1]),
                float(rat_vel[0]), float(rat_vel[1]),
                hd_sin, hd_cos,
                float(frustration),
                float(1.0 if reward_signal > 0 else 0.0),
                float(danger_level),
                float(panic),
                theta_entropy,
                theta_coh,
            ], dtype=float)

            lr = float(config.get("pp_lr", 0.02))
            wd = float(config.get("pp_weight_decay", 0.0005))
            pe_tau = float(config.get("pp_error_tau", 0.4))
            plasticity_gain = float(lc_out.get("plasticity_gain", 1.0)) if lc_out else 1.0
            ach_lr_gain = 1.0 + float(self.last_bf.get("precision_gain", 0.0)) * 0.5
            lr_eff = lr * plasticity_gain * ach_lr_gain * atp_availability

            pp_out = self.pp.step(z_t=z_t, y_t=y_t, lr=lr_eff, weight_decay=wd, dt=dt, pe_tau=pe_tau)
            pe_norm = clamp(pp_out["pe_ema"] * float(config.get("pp_error_scale", 1.5)), 0.0, 1.0)
            self.last_pp = {
                "pe_norm": float(pe_norm),
                "pe_ema": float(pp_out["pe_ema"]),
                "yhat_next": np.array(pp_out["yhat_next"], dtype=float),
            }
        else:
            self.last_pp["pe_norm"] = 0.0

        if config.get("enable_predictive_processing", 0.0) > 0.5:
            bg_exploration = clamp(bg_exploration + self.last_pp["pe_norm"] * float(config.get("pp_explore_gain", 0.5)), 0.0, 1.0)
        else:
            self.last_pp["pe_norm"] = 0.0

        plasticity_mod = (ext_lactate / 0.5) * (0.5 + 0.5 * w_str)
        plasticity_mod *= lc_out["plasticity_gain"]
        if self.last_bf.get("mode", "BALANCED") == "ENCODING":
            plasticity_mod *= 1.1
        elif self.last_bf.get("mode", "BALANCED") == "RECALL":
            plasticity_mod *= 0.9

        mt_plasticity_mult = 1.0
        if config.get("mt_causal", 0.0) > 0.5:
            mt_plast = 1.0 + config.get("mt_mod_plasticity", 0.5) * (theta_r_prev["coherence"] - theta_r_prev["entropy"])
            mt_plast = clamp(mt_plast, 0.5, 1.5)
            plasticity_mod *= mt_plast
            mt_plasticity_mult = mt_plast

        plasticity_mod = float(np.clip(plasticity_mod, 0.0, 5.0))

        # Working memory write/refresh logic (thalamic gating analogue)
        write_drive = (
            0.5 * float(novelty)
            + 0.5 * abs(float(internal_dopamine_phasic))
            + 0.3 * float(frustration)
            + 0.7 * float(danger_level)
        )
        self._wm_write(wm_candidate, write_drive)
        
        # ... rest of the function remains the same ...
        activity_proxy = np.array([np.linalg.norm(sensory_vec), np.linalg.norm(current_memory), frustration])
        consolidation_vector = self.update_stc(activity_proxy, reward_signal)

        if float(np.max(consolidation_vector)) > 0.1:
            if internal_dopamine_total < 0:
                punishment_sensitivity = 1.0 + (1.0 - clamp(float(serotonin), 0.0, 1.0)) * 0.5
                effective_dopamine = internal_dopamine_total * punishment_sensitivity
            else:
                effective_dopamine = internal_dopamine_total
            self.basal_ganglia.w_gate += 0.001 * consolidation_vector * effective_dopamine

        self.pfc.update(sensory_vec, gate_signal)

        angle = float(np.arctan2(final_vector[1], final_vector[0]))
        if angle < 0:
            angle += 2 * np.pi

        soma_input = np.zeros((self.soma.Ny, self.soma.Nx))
        target_idx = int((angle / (2 * np.pi)) * self.soma.Nx) % 13
        soma_input[:, target_idx] += 5.0

        pump_map = soma_input * atp_availability
        d_soma, _ = self.soma.step(pump_map, lfp_signal=0.0, anesthetic_conc=anesthetic_level)

        # --- QUANTUM EVASION: PROJECTING THREATS ---
        # 1. Where is the predator going?
        # We project a "Cone of Death" into the future.
        pred_vec = sim_predator_pos - rat_pos_arr
        
        # Create a threat map on the microtubule grid
        threat_map = np.zeros((self.mt_theta.Ny, self.mt_theta.Nx))
        
        if danger_level > 0.1:
            # Map predator angle to our internal cylinder
            pred_angle = float(np.arctan2(pred_vec[1], pred_vec[0]))
            if pred_angle < 0:
                pred_angle += 2 * np.pi
            
            # Convert angle to column index (0..12)
            pred_col = int((pred_angle / (2 * np.pi)) * self.mt_theta.Nx) % self.mt_theta.Nx
            
            # Paint a "Bar of Entropy" blocking that direction
            threat_map[:, pred_col] = 5.0 
            # Spread to neighbors slightly (uncertainty)
            threat_map[:, (pred_col + 1) % self.mt_theta.Nx] = 2.0
            threat_map[:, (pred_col - 1) % self.mt_theta.Nx] = 2.0

        # 2. Apply to Theta Pump
        theta_pump = (0.5 + (pheromones_len / 200.0)) * atp_availability
        theta_pump_grid = np.ones((self.mt_theta.Ny, self.mt_theta.Nx)) * theta_pump
        
        # Apply the Threat Shield
        theta_pump_grid -= (threat_map * 2.0)
        theta_pump_grid = np.clip(theta_pump_grid, 0.0, 2.0)

        d_theta, _ = self.mt_theta.step(theta_pump_grid, lfp_signal=0.0, anesthetic_conc=anesthetic_level)

        # Microtubule Causal Readouts
        if config.get("mt_causal", 0.0) > 0.5:
            mt_readout_tau = float(config.get("mt_readout_tau", 0.5))
            self.mt_readout_soma = ema(self.mt_readout_soma, self.soma.avg_coherence, mt_readout_tau, dt)
            self.mt_readout_theta = ema(self.mt_readout_theta, self.mt_theta.avg_coherence, mt_readout_tau, dt)

        # Readouts should reflect the current (post-step) state
        soma_r = self.soma.get_readouts()
        theta_r = self.mt_theta.get_readouts()

        if rat_pos is not None:
            self.record_experience(
                rat_pos=np.array(rat_pos, dtype=float),
                sensory_vec=sensory_vec,
                current_memory=current_memory,
                frustration=frustration,
                reward_signal=reward_signal,
                danger_level=danger_level,
                replay_len=int(replay_len),
                near_death=near_death,
            )

        return d_soma, d_theta, self.get_grid_visualization(), final_vector, self.astrocyte.glycogen, self.astrocyte.neuronal_atp, pain, touch, place_metrics, soma_r, theta_r, mt_plasticity_mult, mt_gate_thr, internal_dopamine_total, internal_dopamine_phasic




from tournament import TournamentManager

from predator import Predator

class Cerebellum:
    def __init__(self):
        self.predicted_pos = np.array([0.0, 0.0])
        self.correction_vector = np.array([0.0, 0.0])
        self.learning_rate = 0.1

    def predict(self, current_pos, efference_copy):
        self.predicted_pos = current_pos + (efference_copy * 0.15)

    def update(self, actual_pos):
        error = actual_pos - self.predicted_pos
        self.correction_vector = self.correction_vector * (1 - self.learning_rate) + error * self.learning_rate


class SimulationState:
    def __init__(self):
        self._init_rngs(seed=None)
        self.default_map_name = "quarters"

        self.map_size = 40
        self.rat_pos = np.array([3.0, 3.0])
        self.rat_vel = np.array([0.0, 0.6])
        self.rat_heading = np.pi / 2  # match initial velocity

        self.targets: List[np.ndarray] = []
        self.predator = Predator([35.0, 3.0])
        self.cerebellum = Cerebellum()

        self.score = 0
        self.deaths = 0
        self.frustration = 0.0
        self.dopamine_ema = 0.2       # smoothed total for UI/behaviour
        self.dopamine_tonic = 0.2     # slow baseline mood/motivation
        self.dopamine_phasic = 0.0    # fast PVLV error signal
        self.serotonin = 0.5

        self.state = "AWAKE"
        self.dream_scans = []
        self.phantom_trace = []
        self.pheromones: List[List[float]] = []

        self.dream_timer = 0
        self.panic = 0.0
        self.cortisol = 0.0
        self.behaviour_mode = "SAFE"

        # Deterministic mode contract: same seed, config, and /step batch_size sequence produce identical state/output.
        # Add config defaults + helpful knobs
        self.config = {
            "speed": 1,
            "sensitivity": 0.05,
            "anesthetic": 0.0,
            "downsample": 1,
            "max_speed": 15,
            "dt": 0.05,  # master timestep (kept at legacy default)
            "seed": None,
            "deterministic": 0.0,
            "dopamine_tonic": 0.2,    # baseline tonic dopamine
            # --- NEW KNOBS ---
            "cerebellum_gain": 1.0,  # 0.0 = Clumsy, 1.0 = Precise
            "memory_gain": 1.0,      # 0.0 = Pure Sensory, 1.0 = Balanced
            "fear_gain": 1.0,        # 0.0 = Fearless
            "energy_constraint": 1.0, # 1.0 = Starvation possible, 0.0 = Infinite Energy
            "enable_sensory_cortex": 1.0,   # 0/1
            "enable_thalamus": 1.0,         # 0/1
            "sensory_blend": 1.0,           # 0..1
            # --- REPLAY / HIPPOCAMPUS ---
            "enable_replay": 1.0,       # 0/1
            "replay_steps": 20,          # how many replay items per microsleep
            "replay_len": 1000,          # ring buffer capacity (snapshots)
            "replay_strength": 0.15,    # how much replay affects consolidation
            "replay_bridge_prob": 0.25, # chance to mix in an older memory
            # Microtubule neighbor interpretation
            "mt_neighbor_mode": "legacy",
            # --- NEW STRESS SYSTEM KNOBS ---
            "panic_gain": 1.0,
            "cortisol_gain": 0.5,
            "cortisol_decay": 0.005,
            "panic_trn_gain": 0.5,
            "panic_motor_bias": 0.5,
            "stress_learning_gain": 0.5,
            # --- NEW PLACE CELL KNOBS ---
            "enable_place_cells": 1.0,        # 0/1
            "place_n": 256,                    # number of place cells
            "place_sigma": 1.5,               # spatial tuning width in tiles
            "place_lr": 0.01,                 # Hebbian learning rate
            "place_decay": 0.001,             # weight decay per step
            "place_goal_lr": 0.02,            # learning rate for goal vector readout
            "place_nav_gain": 1.0,            # strength of place-based nav vs other vectors
            "place_nav_blend": 0.35,          # blend proportion into final_vector
            "goal_reward_threshold": 0.5,     # what counts as rewarding for goal learning
            # --- NEW MICROTUBULE CAUSAL KNOBS ---
            "mt_causal": 1.0,                 # 0/1
            "mt_mod_plasticity": 0.5,         # 0..2 multiplier strength
            "mt_mod_explore": 0.3,            # 0..2 exploration noise multiplier strength
            "mt_mod_gate": 0.2,               # 0..2 gate threshold modulation
            "mt_readout_tau": 0.5,            # smoothing for readouts
            # --- PREDICTIVE PROCESSING ---
            "enable_predictive_processing": 1.0,
            "pp_lr": 0.02,
            "pp_weight_decay": 0.0005,
            "pp_error_tau": 0.4,
            "pp_surprise_gain": 1.0,
            "pp_explore_gain": 0.5,
            "pp_error_scale": 1.5,
            # --- WORKING MEMORY ---
            "wm_slots": 5,               # number of WM slots (1-10)
            "wm_write_threshold": 0.2,   # lower = easier to store
            "wm_decay_rate": 0.02,       # per-step decay factor
            "wm_motor_gain": 1.0,        # influence of WM bias on action
        }
        self.brain = DendriticCluster(config=self.config, rng=self.rng_brain, py_rng=self.py_rng, mt_rng=self.rng_microtub, load_genome=True)
        self.apply_runtime_config()

        self.generation = 1
        self.best_fitness = 0.0
        self.frames_alive = 0
        self.run_history: List[float] = []
        self.genes_being_tested = copy.deepcopy(self.brain.weights)
        self.stable_genome = copy.deepcopy(self.brain.weights)

        # Whiskers / vision
        self.whisk_angle = 0.0
        self.whisk_phase = 0.0
        self.whisk_freq = 0.8
        self.whisk_amp = np.pi / 4.0
        self.whisker_hits = [False, False]
        self.vision_buffer: List[Dict[str, Any]] = []
        self.last_collision = False
        self.last_touch = 0.0

        self.lab = ScientificTestBed(self)
        self.lab_reward_flag = False
        self.tournament = TournamentManager(self, self.config, self.map_size)

        if not (float(self.config.get("deterministic", 0.0)) > 0.5):
            if not os.path.exists("evolution_log.csv"):
                with open("evolution_log.csv", "w") as f:
                    f.write("Generation,Fitness,Amygdala,Striatum,Hippocampus\n")
            else:
                try:
                    with open("evolution_log.csv", "r") as f:
                        lines = f.readlines()
                        if len(lines) > 1:
                            self.generation = int(lines[-1].split(",")[0]) + 1
                except Exception:
                    pass

        self.occupancy_grid = np.zeros((self.map_size, self.map_size), dtype=int)
        # Prefer loading a default custom map if present; otherwise generate fresh maze
        if not self._apply_default_map(self.default_map_name):
            self.generate_map()
        # Try to load a preferred default map if it exists
        self._apply_default_map("quarters")

    def _init_rngs(self, seed: Optional[int]):
        base_ss = np.random.SeedSequence(seed)
        child = base_ss.spawn(8)
        self.rng_map = np.random.default_rng(child[0])
        self.rng_brain = np.random.default_rng(child[1])
        self.rng_motion = np.random.default_rng(child[2])
        self.rng_microtub = np.random.default_rng(child[3])
        self.rng_noise = np.random.default_rng(child[4])
        self.rng_misc = np.random.default_rng(child[5])
        py_seed = seed + 1337 if seed is not None else int(child[6].generate_state(1)[0])
        self.py_rng = random.Random(py_seed)

    def deterministic_reset(self):
        self.frames_alive = 0
        self.score = 0
        self.deaths = 0
        self.frustration = 0.0
        self.panic = 0.0
        self.cortisol = 0.0
        self.dopamine_ema = 0.2
        self.dopamine_tonic = 0.2
        self.dopamine_phasic = 0.0
        self.pheromones = []
        self.phantom_trace = []
        self.lab_reward_flag = False

        # Rebuild brain with current seeded streams
        self.brain = DendriticCluster(config=self.config, rng=self.rng_brain, py_rng=self.py_rng, mt_rng=self.rng_microtub, load_genome=False)
        self.brain.soma.neighbor_mode = self.config.get("mt_neighbor_mode", "legacy")
        self.brain.mt_theta.neighbor_mode = self.config.get("mt_neighbor_mode", "legacy")
        det_mode = float(self.config.get("deterministic", 0.0)) > 0.5
        self.brain.soma.deterministic_mode = det_mode
        self.brain.mt_theta.deterministic_mode = det_mode
        self.brain.trn.deterministic_mode = det_mode
        if hasattr(self.brain, "place_cells") and self.brain.place_cells is not None:
            self.brain.place_cells.reset()
        # Regenerate map and reset position/velocity
        if not self._apply_default_map(self.default_map_name):
            self.generate_map()
        self.rat_pos = np.array([3.0, 3.0])
        self.rat_vel = np.array([0.0, 0.6])
        self.rat_heading = np.pi / 2

        # Reset additional state variables for determinism
        self.cerebellum = Cerebellum()
        self.last_touch = 0.0
        self.last_collision = False
        self.whisk_phase = 0.0
        self.vision_buffer = []

    def apply_runtime_config(self):
        # Apply microtubule neighbor interpretation immediately
        mode = str(self.config.get("mt_neighbor_mode", "legacy")).lower()
        mode = mode if mode in {"legacy", "canonical"} else "legacy"
        self.config["mt_neighbor_mode"] = mode
        self.brain.soma.neighbor_mode = mode
        self.brain.mt_theta.neighbor_mode = mode
        det_mode = float(self.config.get("deterministic", 0.0)) > 0.5
        self.brain.soma.deterministic_mode = det_mode
        self.brain.mt_theta.deterministic_mode = det_mode
        self.brain.trn.deterministic_mode = det_mode
        # Propagate RNG stream into replay for deterministic control
        if hasattr(self.brain, "replay"):
            self.brain.replay.py_rng = self.py_rng
            if hasattr(self.brain.replay, "buffer"):
                self.brain.replay.buffer.py_rng = self.py_rng
        if hasattr(self.brain, "basal_ganglia"):
            self.brain.basal_ganglia.rng = self.rng_brain
        if hasattr(self.brain, "soma"):
            self.brain.soma.rng = self.rng_microtub
        if hasattr(self.brain, "mt_theta"):
            self.brain.mt_theta.rng = self.rng_microtub
        if hasattr(self.brain, "rng"):
            self.brain.rng = self.rng_brain
        if hasattr(self.brain, "mt_rng"):
            self.brain.mt_rng = self.rng_microtub
        if hasattr(self.brain, "py_rng"):
            self.brain.py_rng = self.py_rng
        if hasattr(self.brain, "pp") and self.brain.pp is not None:
            self.brain.pp.reset()
            self.brain.last_pp = {"pe_norm": 0.0, "pe_ema": 0.0, "yhat_next": np.zeros(6)}
        if hasattr(self.brain, "bf") and self.brain.bf is not None:
            self.brain.bf = BasalForebrain()
            self.brain.last_bf = {"precision_gain": 0.0, "mode": "BALANCED", "tonic_ach": 0.2}
        if hasattr(self.brain, "_reset_wm"):
            self.brain._reset_wm()
        # Apply WM config knobs
        if hasattr(self.brain, "wm_slots_n"):
            wm_slots_cfg = int(np.clip(int(self.config.get("wm_slots", self.brain.wm_slots_n)), 1, 10))
            if wm_slots_cfg != self.brain.wm_slots_n:
                self.brain.wm_slots_n = wm_slots_cfg
                self.brain._reset_wm()
            self.brain.wm_write_threshold = float(clamp(self.config.get("wm_write_threshold", 0.2), 0.0, 1.0))
            self.brain.wm_decay_rate = float(clamp(self.config.get("wm_decay_rate", 0.02), 0.0, 1.0))
            self.brain.wm_motor_gain = float(clamp(self.config.get("wm_motor_gain", 1.0), 0.0, 5.0))
        
        if self.config.get("enable_place_cells", 0.0) > 0.5:
            if self.brain.place_cells is None or \
               self.brain.place_cells.n_cells != int(self.config["place_n"]) or \
               self.brain.place_cells.sigma != float(self.config["place_sigma"]):
                self.brain.place_cells = PlaceCellNetwork(
                    n_cells=int(self.config["place_n"]),
                    sigma=float(self.config["place_sigma"]),
                    map_size=self.map_size
                )
        else:
            self.brain.place_cells = None

    def reseed(self, seed: int):
        seed = int(seed)
        self._init_rngs(seed)
        self.apply_runtime_config()

    def generate_map(self):
        while True:
            self.occupancy_grid = self.rng_map.choice([0, 1], size=(self.map_size, self.map_size), p=[0.6, 0.4])
            for _ in range(5):
                new_grid = self.occupancy_grid.copy()
                for y in range(1, self.map_size - 1):
                    for x in range(1, self.map_size - 1):
                        neighbors = int(np.sum(self.occupancy_grid[y - 1 : y + 2, x - 1 : x + 2]))
                        if neighbors > 4:
                            new_grid[y, x] = 1
                        elif neighbors < 4:
                            new_grid[y, x] = 0
                self.occupancy_grid = new_grid

            self.occupancy_grid[0, :] = 1
            self.occupancy_grid[-1, :] = 1
            self.occupancy_grid[:, 0] = 1
            self.occupancy_grid[:, -1] = 1

            self.occupancy_grid[1:6, 1:6] = 0
            self.occupancy_grid[34:39, 34:39] = 0
            self.occupancy_grid[1:6, 34:39] = 0

            # BFS reachability
            test_grid = self.occupancy_grid.copy()
            start = (3, 3)
            queue = [start]
            test_grid[start] = 2
            reachable_tiles = [start]

            while queue:
                cx, cy = queue.pop(0)
                for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                    nx, ny = cx + dx, cy + dy
                    if 0 <= nx < self.map_size and 0 <= ny < self.map_size:
                        if test_grid[ny, nx] == 0:
                            test_grid[ny, nx] = 2
                            queue.append((nx, ny))
                            reachable_tiles.append((nx, ny))

            if len(reachable_tiles) > 200:
                self.rat_pos = np.array([3.0, 3.0])
                reachable_tiles.sort(key=lambda p: (p[0] - 3) ** 2 + (p[1] - 3) ** 2)

                self.targets = [self._spawn_single_target() for _ in range(3)]

                far_tiles = [t for t in reachable_tiles if (t[0] - 3) ** 2 + (t[1] - 3) ** 2 > 200]
                if far_tiles:
                    idx = int(self.rng_map.integers(len(far_tiles)))
                    p_spawn = far_tiles[idx]
                    self.predator = Predator([float(p_spawn[0]), float(p_spawn[1])])
                    self.pheromones = []
                    self.brain.astrocyte = Astrocyte()
                    break

    def _apply_custom_grid(self, grid: np.ndarray):
        if grid.shape != (self.map_size, self.map_size):
            return False
        self.occupancy_grid = grid.copy()
        self.occupancy_grid[0, :] = 1
        self.occupancy_grid[-1, :] = 1
        self.occupancy_grid[:, 0] = 1
        self.occupancy_grid[:, -1] = 1
        self.targets = [self._spawn_single_target() for _ in range(3)]
        self.rat_pos = np.array([3.0, 3.0])
        self.rat_vel = np.array([0.0, 0.6])
        if hasattr(self, "predator") and self.predator is not None:
            self.predator.pos = np.array([-100.0, -100.0])
        self.pheromones = []
        if hasattr(self.brain, "place_cells") and self.brain.place_cells is not None:
            self.brain.place_cells.reset()
        return True

    def _apply_default_map(self, name: str):
        data = load_custom_maps_data()
        if name not in data:
            return False
        grid = np.array(data[name], dtype=int)
        return self._apply_custom_grid(grid)

    def check_collision(self, pos):
        def is_wall(x, y):
            ix, iy = int(x), int(y)
            if ix < 0 or ix >= self.map_size or iy < 0 or iy >= self.map_size:
                return True
            return self.occupancy_grid[iy, ix] == 1

        if is_wall(pos[0], pos[1]):
            return True

        radius = 0.3
        if is_wall(pos[0] + radius, pos[1]):
            return True
        if is_wall(pos[0] - radius, pos[1]):
            return True
        if is_wall(pos[0], pos[1] + radius):
            return True
        if is_wall(pos[0], pos[1] - radius):
            return True

        return False

    def _spawn_single_target(self):
        while True:
            tx = int(self.rng_map.integers(1, self.map_size - 1))
            ty = int(self.rng_map.integers(1, self.map_size - 1))
            if self.occupancy_grid[ty, tx] != 0:
                continue

            # BFS reachability
            test_grid = self.occupancy_grid.copy()
            start = (int(self.rat_pos[0]), int(self.rat_pos[1]))
            queue = [start]
            test_grid[start[1], start[0]] = 2

            reachable = False
            steps = 0
            max_steps = self.map_size * self.map_size

            while queue and steps < max_steps:
                cx, cy = queue.pop(0)
                if cx == tx and cy == ty:
                    reachable = True
                    break
                steps += 1
                for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                    nx, ny = cx + dx, cy + dy
                    if 0 <= nx < self.map_size and 0 <= ny < self.map_size:
                        if test_grid[ny, nx] == 0:
                            test_grid[ny, nx] = 2
                            queue.append((nx, ny))

            if reachable:
                return np.array([float(tx), float(ty)])

    def cast_ray(self, angle: float):
        dx, dy = np.cos(angle), np.sin(angle)

        min_dist = 15.0
        obj_type = 0

        # walls first
        for d in np.linspace(0, 15.0, 30):
            cx = self.rat_pos[0] + dx * d
            cy = self.rat_pos[1] + dy * d
            if self.check_collision([cx, cy]):
                min_dist = float(d)
                obj_type = 1
                break

        # predator (angle wrap aware)
        to_predator = self.predator.pos - self.rat_pos
        dist_predator = float(np.linalg.norm(to_predator))
        if dist_predator > 0:
            pred_angle = float(np.arctan2(to_predator[1], to_predator[0]))
            if angdiff(angle, pred_angle) < 0.1:
                if dist_predator < min_dist:
                    min_dist = dist_predator
                    obj_type = 2

        # targets (angle wrap aware)
        for target in self.targets:
            to_target = target - self.rat_pos
            dist_target = float(np.linalg.norm(to_target))
            if dist_target > 0:
                target_angle = float(np.arctan2(to_target[1], to_target[0]))
                if angdiff(angle, target_angle) < 0.1:
                    if dist_target < min_dist:
                        min_dist = dist_target
                        obj_type = 3

        return min_dist, obj_type

    def process_vision(self):
        self.vision_buffer = []
        heading = float(np.arctan2(self.rat_vel[1], self.rat_vel[0]))
        fov = np.pi * (2 / 3)

        for i in range(12):
            angle_offset = (i / 11.0 - 0.5) * fov
            ray_angle = heading + angle_offset
            dist, obj_type = self.cast_ray(ray_angle)
            self.vision_buffer.append({"dist": float(dist), "type": int(obj_type), "angle": float(ray_angle)})

    def update_whiskers(self):
        dt_local = float(self.config.get("dt", BASE_DT))
        dt_scale = dt_local / BASE_DT
        self.whisk_phase += self.whisk_freq * dt_scale
        self.whisk_angle = float(np.sin(self.whisk_phase) * self.whisk_amp)

        angles = [(-np.pi / 4) + self.whisk_angle, (np.pi / 4) - self.whisk_angle]

        heading = float(np.arctan2(self.rat_vel[1], self.rat_vel[0]))
        self.whisker_hits = [False, False]
        whisker_length = 5.0

        for i, angle in enumerate(angles):
            global_angle = heading + angle
            tip_x = self.rat_pos[0] + np.cos(global_angle) * whisker_length
            tip_y = self.rat_pos[1] + np.sin(global_angle) * whisker_length

            mid_x = self.rat_pos[0] + np.cos(global_angle) * (whisker_length * 0.5)
            mid_y = self.rat_pos[1] + np.sin(global_angle) * (whisker_length * 0.5)

            if self.check_collision([mid_x, mid_y]) or self.check_collision([tip_x, tip_y]):
                self.whisker_hits[i] = True

    def die(self):
        fitness = (self.score * 100) + (self.frames_alive * 0.01)
        self.run_history.append(float(fitness))
        BATCH_SIZE = 5

        if not (float(self.config.get("deterministic", 0.0)) > 0.5):
            with open("evolution_log.csv", "a") as f:
                f.write(
                    f"{self.generation},{fitness:.2f},{self.brain.weights['amygdala']:.3f},{self.brain.weights['striatum']:.3f},{self.brain.weights['hippocampus']:.3f}\n"
                )

        if len(self.run_history) >= BATCH_SIZE:
            avg_fitness = sum(self.run_history) / len(self.run_history)
            print(f"Gen {self.generation} Batch Avg: {avg_fitness:.2f} vs Best: {self.best_fitness:.2f}")

            if avg_fitness > self.best_fitness:
                self.best_fitness = avg_fitness
                self.stable_genome = copy.deepcopy(self.genes_being_tested)
                if not (float(self.config.get("deterministic", 0.0)) > 0.5):
                    self.brain.save_memory()
                print(">>> NEW BEST GENOME SAVED <<<")

            self.brain.weights = copy.deepcopy(self.stable_genome)

            mutation_rate = 0.2
            for k in self.brain.weights:
                change = 1.0 + float(self.rng_misc.normal(0, mutation_rate))
                self.brain.weights[k] = max(0.1, min(10.0, self.brain.weights[k] * change))

            self.genes_being_tested = copy.deepcopy(self.brain.weights)
            self.run_history = []
            self.generation += 1

        self.deaths += 1
        self.frames_alive = 0
        self.rat_pos = np.array([3.0, 3.0])
        self.rat_vel = np.array([0.0, 0.6])
        self.rat_heading = np.pi / 2
        self.pheromones = []
        self.frustration = 0.0
        self.panic = 0.0
        self.cortisol = 0.0
        self.behaviour_mode = "SAFE"

        # reset short-term state
        self.brain.astrocyte = Astrocyte()
        self.brain.trn = TRNGate()
        self.brain.trn.deterministic_mode = (float(self.config.get("deterministic", 0.0)) > 0.5)
        if hasattr(self.brain, "basal_ganglia"):
            self.brain.basal_ganglia.reset()
        else:
            self.brain.basal_ganglia = BasalGanglia(rng=self.rng_brain)
        if hasattr(self.brain, "place_cells") and self.brain.place_cells is not None:
            self.brain.place_cells.reset()
        self.brain.place_memories = []

        while True:
            tx = int(self.rng_map.integers(1, 39))
            ty = int(self.rng_map.integers(1, 39))
            if self.occupancy_grid[ty, tx] == 0:
                dist = (tx - 3) ** 2 + (ty - 3) ** 2
                if dist > 200:
                    self.predator = Predator([float(tx), float(ty)])
                    break


# --- LAB PROTOCOLS ---

class LabProtocol:
    """Base class for all experiments."""
    def __init__(self):
        self.name = "Generic"
        self.max_frames = 1000

    def setup(self, sim):
        """Reset map, place rat, set constraints."""
        pass

    def step(self, sim, timer) -> Optional[Dict[str, Any]]:
        """Run per-frame logic. Return dict of data to log, or None."""
        return None

    def is_complete(self, sim, timer):
        return timer >= self.max_frames


class OpenFieldProtocol(LabProtocol):
    """
    Standard Anxiety/Exploration Test.
    - Environment: Empty box.
    - Metrics: Thigmotaxis (wall hugging) vs Center Time.
    - Hypothesis: High Entropy rats should cross the center. High Anxiety rats hug walls.
    """
    def __init__(self):
        self.name = "Open Field Test"
        self.max_frames = 1000 # Approx 50 seconds at 20fps
        self.center_zone_radius = 12.0 # Map is 40x40, center is ~20 units wide

    def setup(self, sim):
        # 1. Clear Map (Empty Box)
        sim.map_size = 40
        # Rebuild grid in case a prior test used a different size
        sim.occupancy_grid = np.zeros((sim.map_size, sim.map_size), dtype=int)
        # Add outer walls
        sim.occupancy_grid[0, :] = 1
        sim.occupancy_grid[-1, :] = 1
        sim.occupancy_grid[:, 0] = 1
        sim.occupancy_grid[:, -1] = 1

        # 2. Reset Agents
        sim.rat_pos = np.array([20.0, 20.0]) # Start in Center
        sim.rat_vel = np.array([0.0, 0.0])
        sim.predator.pos = np.array([-100.0, -100.0]) # Remove predator
        sim.targets = [] # No food
        sim.pheromones = []
        
        # 3. Reset Brain State (Fresh subject)
        sim.frustration = 0.0
        sim.dopamine_tonic = 0.5
        sim.dopamine_ema = 0.5
        sim.brain.astrocyte.glycogen = 1.0
        
        # Important: Ensure High Entropy start for testing curiosity
        sim.brain.mt_theta.reset_wavefunction() 

    def step(self, sim, timer):
        # Calculate distance from center (20, 20)
        dist_from_center = np.linalg.norm(sim.rat_pos - np.array([20.0, 20.0]))
        in_center = dist_from_center < self.center_zone_radius
        
        # Calculate speed
        speed = np.linalg.norm(sim.rat_vel)
        
        return {
            "frame": timer,
            "in_center": 1 if in_center else 0,
            # Keep both keys: existing "dist_from_center" plus generic "dist"
            # so the plotting code can handle all protocols uniformly.
            "dist_from_center": float(dist_from_center),
            "dist": float(dist_from_center),
            "speed": float(speed),
            "entropy": float(sim.brain.mt_theta.readout["entropy"])
        }


class TMazeProtocol(LabProtocol):
    """
    T-Maze Delayed Alternation Task (Multi-Trial).
    
    Each trial:
    - Phase 1 (Forced): Block one arm, force rat to the other. Reward.
    - Phase 2 (Delay): Teleport to start, wait N frames.
    - Phase 3 (Choice): Open both arms. Correct = OPPOSITE arm from forced.
    
    Across trials, the forced arm alternates (L, R, L, R...).
    Metric: % correct alternation across trials.
    """
    def __init__(self):
        self.name = "T-Maze Alternation"
        self.max_frames = 20000  # Total budget across all trials
        self.max_frames_per_phase = 1500  # Timeout per phase
        
        self.total_trials = 10
        self.current_trial = 0
        self.phase = "setup"
        self.phase_timer = 0
        self.delay_duration = 100
        
        # Results tracking
        self.results = []  # List of {trial, forced_arm, choice, correct, latency}
        self.last_score = 0
        
        # Coordinates (for 40x40 map)
        self.start_pos = np.array([20.0, 5.0])
        self.t_junction = np.array([20.0, 28.0])
        self.left_arm = np.array([5.0, 30.0])
        self.right_arm = np.array([35.0, 30.0])
        
        # Which arm to force on this trial (alternates)
        self.forced_arm = "left"
        self.finished = False

    def setup(self, sim):
        sim.map_size = 40
        sim.occupancy_grid.fill(1)
        
        # Carve the permanent T structure
        self._carve_t_maze(sim)
        
        # Reset agents
        sim.predator.pos = np.array([-100.0, -100.0])
        sim.pheromones = []
        
        # Reset brain state
        sim.frustration = 0.0
        sim.dopamine_tonic = 0.5
        sim.dopamine_ema = 0.5
        sim.brain.astrocyte.glycogen = 1.0
        sim.brain.astrocyte.neuronal_atp = 1.0
        sim.brain.pfc.memory.fill(0.0)
        
        # Randomize first forced arm
        self.forced_arm = "left" if sim.py_rng.random() < 0.5 else "right"
        
        # Start first trial
        self.current_trial = 1
        self.results = []
        self.finished = False
        self._start_forced_phase(sim)
        
        print(f"LAB: T-Maze Multi-Trial Started. {self.total_trials} trials.")

    def _carve_t_maze(self, sim):
        """Carve the basic T shape (without arm blocking)."""
        sim.occupancy_grid.fill(1)
        
        # Vertical stem (wide enough for rat)
        sim.occupancy_grid[3:31, 17:24] = 0
        
        # Horizontal bar at top
        sim.occupancy_grid[27:33, 3:38] = 0
        
        # Start box
        sim.occupancy_grid[1:5, 17:24] = 0

    def _start_forced_phase(self, sim):
        """Begin the forced run phase of a trial."""
        self.phase = "forced"
        self.phase_timer = 0
        
        # Re-carve maze and block the non-forced arm
        self._carve_t_maze(sim)
        
        if self.forced_arm == "left":
            # Block right arm
            sim.occupancy_grid[27:33, 24:38] = 1
            target = self.left_arm.copy()
        else:
            # Block left arm
            sim.occupancy_grid[27:33, 3:17] = 1
            target = self.right_arm.copy()
        
        # Place rat and target
        sim.rat_pos = self.start_pos.copy()
        sim.rat_vel = np.array([0.0, 0.0])
        sim.targets = [target]
        
        print(f"LAB: Trial {self.current_trial} - Forced to {self.forced_arm.upper()}")

    def _start_delay_phase(self, sim):
        """Begin the delay phase."""
        self.phase = "delay"
        self.phase_timer = 0
        
        # Teleport rat back to start
        sim.rat_pos = self.start_pos.copy()
        sim.rat_vel = np.array([0.0, 0.0])
        sim.targets = []  # Hide target during delay
        
        print(f"LAB: Trial {self.current_trial} - Delay phase ({self.delay_duration} frames)")

    def _start_choice_phase(self, sim):
        """Begin the choice phase - both arms open."""
        self.phase = "choice"
        self.phase_timer = 0
        
        # Open both arms
        self._carve_t_maze(sim)
        
        # Correct target is OPPOSITE of forced arm
        if self.forced_arm == "left":
            correct_target = self.right_arm.copy()
        else:
            correct_target = self.left_arm.copy()
        
        sim.targets = [correct_target]
        
        # Release rat from start
        sim.rat_pos = self.start_pos.copy()
        sim.rat_vel = np.array([0.0, 0.0])
        
        print(f"LAB: Trial {self.current_trial} - Choice phase (correct = {('RIGHT' if self.forced_arm == 'left' else 'LEFT')})")

    def _end_trial(self, sim, chose_correct: bool, latency: int):
        """Record result and prepare next trial."""
        result = {
            "trial": self.current_trial,
            "forced_arm": self.forced_arm,
            "correct": 1 if chose_correct else 0,
            "latency": latency
        }
        self.results.append(result)
        
        status = "CORRECT" if chose_correct else "WRONG"
        print(f"LAB: Trial {self.current_trial} - {status} (latency: {latency})")
        
        if chose_correct:
            sim.score += 10
            sim.lab_reward_flag = True
        else:
            sim.frustration = min(1.0, sim.frustration + 0.3)
        
        # Prepare next trial
        if self.current_trial < self.total_trials:
            self.current_trial += 1
            # Alternate the forced arm
            self.forced_arm = "right" if self.forced_arm == "left" else "left"
            self._start_forced_phase(sim)
        else:
            self.finished = True
            self._print_summary()

    def _print_summary(self):
        """Print final results."""
        correct_count = sum(r["correct"] for r in self.results)
        total = len(self.results)
        pct = (correct_count / total * 100) if total > 0 else 0
        
        print(f"\n{'='*50}")
        print(f"T-MAZE RESULTS: {correct_count}/{total} correct ({pct:.1f}%)")
        print(f"{'='*50}")
        for r in self.results:
            mark = "✓" if r["correct"] else "✗"
            print(f"  Trial {r['trial']}: Forced {r['forced_arm']:5s} -> {mark} (latency: {r['latency']})")
        print(f"{'='*50}\n")

    def step(self, sim, timer):
        if self.finished:
            return None
        
        self.phase_timer += 1
        
        # --- FORCED PHASE ---
        if self.phase == "forced":
            if len(sim.targets) > 0:
                dist = np.linalg.norm(sim.rat_pos - sim.targets[0])
                if dist < 1.5:
                    # Reached forced target - reward and move to delay
                    sim.lab_reward_flag = True
                    sim.brain.astrocyte.glycogen = 1.0
                    self._start_delay_phase(sim)
                    return {"frame": timer, "trial": self.current_trial, "phase": 1}
            
            # Timeout in forced phase (shouldn't happen normally)
            if self.phase_timer > self.max_frames_per_phase:
                print(f"LAB: Trial {self.current_trial} - Forced phase TIMEOUT")
                self._start_delay_phase(sim)
        
        # --- DELAY PHASE ---
        elif self.phase == "delay":
            # Lock rat in start area
            sim.rat_pos = self.start_pos.copy()
            sim.rat_vel = np.array([0.0, 0.0])
            
            if self.phase_timer >= self.delay_duration:
                self._start_choice_phase(sim)
            
            return {"frame": timer, "trial": self.current_trial, "phase": 2}
        
        # --- CHOICE PHASE ---
        elif self.phase == "choice":
            # Check if reached correct target
            if len(sim.targets) > 0:
                dist_correct = np.linalg.norm(sim.rat_pos - sim.targets[0])
                if dist_correct < 1.5:
                    self._end_trial(sim, chose_correct=True, latency=self.phase_timer)
                    return self._make_data_point(timer)
            
            # Check if reached wrong target
            wrong_target = self.left_arm if self.forced_arm == "left" else self.right_arm
            dist_wrong = np.linalg.norm(sim.rat_pos - wrong_target)
            if dist_wrong < 1.5:
                self._end_trial(sim, chose_correct=False, latency=self.phase_timer)
                return self._make_data_point(timer)
            
            # Timeout
            if self.phase_timer > self.max_frames_per_phase:
                print(f"LAB: Trial {self.current_trial} - Choice phase TIMEOUT (counting as wrong)")
                self._end_trial(sim, chose_correct=False, latency=self.phase_timer)
                return self._make_data_point(timer)
        
        return {"frame": timer, "trial": self.current_trial, "phase": self._phase_num()}

    def _phase_num(self):
        return {"forced": 1, "delay": 2, "choice": 3}.get(self.phase, 0)

    def _make_data_point(self, timer):
        """Generate data point for plotting."""
        return {
            "frame": self.current_trial,  # X-axis = trial number
            "correct": self.results[-1]["correct"] if self.results else 0,
            "latency": self.results[-1]["latency"] if self.results else 0,
            "cumulative_pct": sum(r["correct"] for r in self.results) / len(self.results) * 100 if self.results else 0
        }

    def is_complete(self, sim, timer):
        return self.finished or timer >= self.max_frames


class MorrisWaterMazeProtocol(LabProtocol):
    """
    Spatial Learning / Long Term Memory Test.
    - Setup: Open arena. Target FIXED in one location (beyond visual range from start).
    - Trial: Rat starts at random locations (N, S, E, W).
    - Inter-Trial: Massive Replay/Consolidation burst (Simulating 'Sleep').
    - Metric: Latency to find target. Should decrease over trials.
    """
    def __init__(self):
        self.name = "Morris Water Maze"
        self.max_frames_per_trial = 1500
        self.total_trials = 10
        
        self.current_trial = 1
        self.trial_timer = 0
        self.finished = False
        self.target_pos = np.array([20.0, 20.0])
        self.start_positions = []
        self.pending_next_trial = False

    def setup(self, sim):
        # 1. Clear Map
        sim.map_size = 40
        sim.occupancy_grid = np.zeros((sim.map_size, sim.map_size), dtype=int)
        sim.occupancy_grid[0, :] = 1
        sim.occupancy_grid[-1, :] = 1
        sim.occupancy_grid[:, 0] = 1
        sim.occupancy_grid[:, -1] = 1

        # Set fixed target at true center (per request)
        self.target_pos = np.array([20.0, 20.0])
        # Start positions: four corners inset to avoid walls
        pad = 3.0
        ms = sim.map_size
        self.start_positions = [
            np.array([pad, pad]),  # SW
            np.array([pad, ms - pad]),  # NW
            np.array([ms - pad, pad]),  # SE
            np.array([ms - pad, ms - pad]),  # NE
        ]

        # 2. Reset Agents
        sim.predator.pos = np.array([-100.0, -100.0])
        sim.pheromones = []
        
        # 3. Reset Brain (Fresh Subject)
        sim.brain.astrocyte.glycogen = 1.0
        sim.brain.astrocyte.neuronal_atp = 1.0
        sim.frustration = 0.0
        sim.dopamine_tonic = 0.5
        sim.dopamine_ema = 0.5
        self.pending_next_trial = False
        
        # Reset Place Cells to ensure we are testing *new* learning
        if sim.config.get("enable_place_cells", 0.0) > 0.5:
            sim.brain.place_cells = PlaceCellNetwork(
                n_cells=int(sim.config.get("place_n", 256)),
                sigma=float(sim.config.get("place_sigma", 1.5)),
                map_size=sim.map_size,
            )
        elif sim.brain.place_cells:
            sim.brain.place_cells.reset()
            
        # Start Trial 1
        self.start_new_trial(sim)
        print(f"LAB: Water Maze Started. Target at {self.target_pos}")

    def start_new_trial(self, sim):
        # Pick random start point
        start_pos = self.start_positions[sim.py_rng.randrange(len(self.start_positions))]
        sim.rat_pos = start_pos.copy()
        sim.rat_vel = np.array([0.0, 0.0])
        
        # Place Target
        sim.targets = [self.target_pos.copy()]
        
        # Reset trial timer
        self.trial_timer = 0
        
        # Boost frustration slightly to motivate "swimming"
        sim.frustration = 0.2

    def step(self, sim, timer):
        if self.finished: return None

        # If we deferred starting the next trial, do it now (after reward was processed)
        if self.pending_next_trial and self.current_trial <= self.total_trials:
            self.start_new_trial(sim)
            self.pending_next_trial = False

        self.trial_timer += 1
        
        # Check Success
        dist = np.linalg.norm(sim.rat_pos - self.target_pos)
        success = dist < 1.5
        
        # Check Timeout
        timeout = self.trial_timer >= self.max_frames_per_trial
        
        if success or timeout:
            result_time = self.trial_timer
            status = "SUCCESS" if success else "TIMEOUT"
            print(f"LAB: Trial {self.current_trial} {status} in {result_time} frames.")
            if success:
                # Flag reward; main loop will process before we teleport
                sim.lab_reward_flag = True
            
            # --- CRITICAL: THE "NIGHT" PHASE ---
            # Trigger massive replay to consolidate the path
            if sim.config.get("enable_replay", 0.0) > 0.5:
                print("LAB: Consolidating memory (Dreaming)...")
                # We force 3 cycles of replay to ensure the Place Cells/BG get updated
                for _ in range(3):
                    sim.brain.offline_replay_and_consolidate(
                        steps=20, 
                        bridge_prob=0.5, 
                        strength=0.2,
                        stress_learning_gain=1.0 # High gain because finding the platform is life-or-death
                    )

            # Prepare next trial
            if self.current_trial < self.total_trials:
                self.current_trial += 1
                self.pending_next_trial = True
            else:
                self.finished = True

            # Return data point for the graph
            # We normalize 1500 frames to "height" of graph
            return {
                "frame": self.current_trial, # X-axis = Trial Number
                "latency": result_time,      # Y-axis = Time to find
                "success": 1 if success else 0
            }
            
        return None # No data point until trial ends

    def is_complete(self, sim, timer):
        return self.finished


class SurvivalProtocol(LabProtocol):
    """
    Predator Evasion / Survival Test.
    - Setup: Small arena. 1 Rat. 1 Aggressive Predator.
    - Metric: Frames alive.
    - Hypothesis: Predictive evasion (Quantum Shield) increases survival time vs reactive fleeing.
    """
    def __init__(self):
        self.name = "Survival Arena (Thunderdome)"
        self.max_frames = 2000
        self.finished = False
        self.survival_time = 0

    def setup(self, sim):
        # 1. Small Arena (20x20) - Harder to run away
        sim.map_size = 20
        sim.occupancy_grid = np.zeros((20, 20), dtype=int)
        sim.occupancy_grid[0, :] = 1
        sim.occupancy_grid[-1, :] = 1
        sim.occupancy_grid[:, 0] = 1
        sim.occupancy_grid[:, -1] = 1

        # 2. Place Combatants
        sim.rat_pos = np.array([10.0, 10.0])
        sim.rat_vel = np.array([0.0, 0.0])
        sim.predator.pos = np.array([2.0, 2.0]) # Start corner
        sim.predator.speed = 0.24 # Fast
        
        sim.targets = [] # No food, only survival
        
        # 3. Reset Stats
        sim.frustration = 0.0
        sim.dopamine_tonic = 0.8 # High focus baseline required
        sim.dopamine_ema = sim.dopamine_tonic
        sim.brain.astrocyte.glycogen = 1.0
        
        print("LAB: Survival Arena Started. GOOD LUCK.")

    def step(self, sim, timer):
        if self.finished:
            return None
        
        # Check Death
        dist = np.linalg.norm(sim.rat_pos - sim.predator.pos)
        if dist < 1.0:
            print(f"LAB: Rat Caught at frame {timer}!")
            self.finished = True
            self.survival_time = timer
        
        # Return simple survival counter
        return {
            "frame": timer,
            "alive": 1 if not self.finished else 0,
            "dist": float(dist)
        }

    def is_complete(self, sim, timer):
        return self.finished or timer >= self.max_frames


class CustomProtocol(LabProtocol):
    def __init__(self, config: Dict[str, Any]):
        self.name = config.get("name", "Custom Protocol")
        self.max_frames = int(config.get("duration", 1000))
        self.config = config
        self.finished = False
        
        # Mode determines success logic: 'reach_target', 'survive', or 'explore'
        self.mode = config.get("objective", "reach_target") 

    def setup(self, sim):
        # 1. Map & Geometry
        sim.map_size = int(self.config.get("map_size", 20))
        
        if "grid" in self.config:
            sim.occupancy_grid = np.array(self.config["grid"], dtype=int)
        else:
            sim.occupancy_grid = np.zeros((sim.map_size, sim.map_size), dtype=int)
            # Build Walls (Default: Box)
            sim.occupancy_grid[0, :] = 1
            sim.occupancy_grid[-1, :] = 1
            sim.occupancy_grid[:, 0] = 1
            sim.occupancy_grid[:, -1] = 1
        
        # 2. Reset Agents
        start_pos = self.config.get("rat_start", [2.0, 2.0])
        sim.rat_pos = np.array([float(start_pos[0]), float(start_pos[1])])
        sim.rat_vel = np.array([0.0, 0.0])
        
        # 3. Predator
        if self.config.get("has_predator", False):
            pred_start = self.config.get("predator_start", [sim.map_size-3.0, sim.map_size-3.0])
            sim.predator.pos = np.array([float(pred_start[0]), float(pred_start[1])])
            sim.predator.speed = float(self.config.get("predator_speed", 0.24))
        else:
            sim.predator.pos = np.array([-100.0, -100.0])

        # 4. Targets / Food
        sim.targets = []
        target_locs = self.config.get("targets", [])
        for t in target_locs:
            sim.targets.append(np.array([float(t[0]), float(t[1])]))

        # 5. Brain State Reset
        sim.frustration = 0.0
        sim.dopamine_tonic = 0.5
        sim.brain.astrocyte.glycogen = 1.0
        
        print(f"LAB: Custom Protocol '{self.name}' Initiated.")

    def step(self, sim, timer):
        if self.finished: return None

        # Logic varies by Objective Mode
        success = False
        failure = False
        dist = 999.0
        
        # Mode: Reach Target (Navigation)
        if self.mode == "reach_target":
            for t in sim.targets:
                d = np.linalg.norm(sim.rat_pos - t)
                if d < dist:
                    dist = d
                if d < 1.5:
                    success = True
                    sim.lab_reward_flag = True # Trigger reward in main loop
        
        # Mode: Survival (Predator Evasion)
        elif self.mode == "survive":
            dist = np.linalg.norm(sim.rat_pos - sim.predator.pos)
            if dist < 1.0:
                failure = True
            elif timer >= self.max_frames:
                success = True # Survived the whole time

        if success or failure:
            self.finished = True
            status = "SUCCESS" if success else "FAILURE"
            print(f"LAB: Custom Test Finished: {status}")
            
            return {
                "frame": timer,
                "success": 1 if success else 0,
                "latency": timer,
                "dist": float(dist)
            }

        return {
            "frame": timer,
            "dist": float(dist)
        }

    def is_complete(self, sim, timer):
        return self.finished or timer >= self.max_frames


class ScientificTestBed:
    def __init__(self, simulation):
        self.sim = simulation
        self.active = False
        self.protocol = None
        self.data_log = []
        self.timer = 0
        
        # Registry of available tests
        self.protocols = {
            "open_field": OpenFieldProtocol,
            "t_maze": TMazeProtocol,
            "spatial_learning": MorrisWaterMazeProtocol,
            "survival": SurvivalProtocol,
        }

    def start_experiment(self, protocol_name="open_field", custom_config=None):
        print(f">>> STARTING LAB: {protocol_name.upper()} <<<")
        self.active = True
        self.data_log = []
        self.timer = 0
        
        if protocol_name == "custom" and custom_config:
            # Instantiate the dynamic protocol
            self.protocol = CustomProtocol(custom_config)
        elif protocol_name in self.protocols:
            # Instantiate standard hardcoded protocols
            ProtocolClass = self.protocols[protocol_name]
            self.protocol = ProtocolClass()
        else:
            print(f"Unknown protocol: {protocol_name}")
            self.active = False
            return

        self.protocol.setup(self.sim)

    def stop_experiment(self):
        self.active = False
        self.protocol = None
        print(">>> EXPERIMENT ENDED <<<")

    def step(self):
        if not self.active or not self.protocol:
            return

        self.timer += 1
        
        # Run protocol logic
        data_point = self.protocol.step(self.sim, self.timer)
        if data_point:
            self.data_log.append(data_point)

        # Check for completion
        if self.protocol.is_complete(self.sim, self.timer):
            self.stop_experiment()

    def get_results(self):
        return {
            "active": self.active,
            "protocol": self.protocol.name if self.protocol else None,
            "data_points": len(self.data_log),
            "data": self.data_log # Send full log to frontend for plotting
        }


sim = SimulationState()


@app.route("/")
def index():
    return render_template("index.html")


def serialize_state(
    soma_density: np.ndarray,
    theta_density: np.ndarray,
    grid: np.ndarray,
    downsample: int,
) -> Dict[str, Any]:
    soma_out = maybe_downsample(soma_density, downsample)
    theta_out = maybe_downsample(theta_density, downsample)
    grid_out = maybe_downsample(grid, downsample)

    return {
        "soma": soma_out.tolist(),
        "theta": theta_out.tolist() if isinstance(theta_out, np.ndarray) else float(theta_out),
        "grid": grid_out.tolist(),
        "hd": maybe_downsample(sim.brain.hd_cells, 1).tolist(),
    }


@app.route("/step", methods=["POST"])
def step():
    with sim_lock:
        req_data = request.json or {}

        # Clamp iterations
        requested = req_data.get("batch_size", sim.config["speed"])
        try:
            iterations = int(requested)
        except Exception:
            iterations = int(sim.config["speed"])

        max_speed = int(sim.config.get("max_speed", 10))
        iterations = int(np.clip(iterations, 1, max_speed))

        anesthetic_level = clamp(float(sim.config.get("anesthetic", 0.0)), 0.0, 1.0)
        downsample = int(sim.config.get("downsample", 1))
        downsample = int(np.clip(downsample, 1, 8))
        dt = float(sim.config.get("dt", 0.05))
        dt_scale = dt / BASE_DT

        # Default placeholders so we can always return on last frame
        soma_density = np.zeros((sim.brain.soma.Ny, sim.brain.soma.Nx), dtype=float)
        d_theta = np.zeros((sim.brain.mt_theta.Ny, sim.brain.mt_theta.Nx), dtype=float)
        d_grid = np.zeros((32, 32), dtype=float)
        glycogen_level = float(sim.brain.astrocyte.glycogen)
        atp_level = float(sim.brain.astrocyte.neuronal_atp)

        # --- TOURNAMENT MODE BRANCH ---
        if sim.tournament.active:
            tournament_rats = []
            leader = None
            living_rats = []
            tournament_status = ""

            for i in range(iterations):
                # Ensure arena has targets
                if not sim.targets:
                    sim.targets = [sim._spawn_single_target() for _ in range(8)]

                env_state = {
                    "grid": sim.occupancy_grid,
                    "targets": sim.targets,
                    "predators": [p.pos for p in sim.tournament.predators],
                }
                tournament_rats = sim.tournament.step(dt, env_state)
                sim.frames_alive += 1

                for predator in sim.tournament.predators:
                    predator.patrol_wall(sim.map_size, dt_scale)

                living_rats = [a for a in sim.tournament.agents if a.deaths == 0]

                if sim.frames_alive > 2000 or not living_rats:
                    finished = sim.tournament.end_round()
                    sim.frames_alive = 0
                    # Reset trails/targets each round
                    sim.tournament._create_quartered_map_and_food()
                    sim.pheromones = []
                    if finished:
                        print("TOURNAMENT COMPLETE")
                        tournament_status = "COMPLETE"
                    else:
                        tournament_status = ""

            if sim.tournament.agents:
                leader = max(sim.tournament.agents, key=lambda a: a.score)
                if living_rats:
                    leader = max(living_rats, key=lambda a: a.score)
            
            # Populate viz from leader or fall back to placeholders
            leader_data = leader.brain_data if leader else {}
            soma_density = np.array(leader_data.get("soma", soma_density))
            d_theta = np.array(leader_data.get("theta", d_theta))
            d_grid = np.array(leader_data.get("grid", d_grid))

            brain_payload = {
                "soma": maybe_downsample(soma_density, downsample).tolist(),
                "theta": maybe_downsample(d_theta, downsample).tolist() if isinstance(d_theta, np.ndarray) else float(d_theta),
                "grid": maybe_downsample(d_grid, downsample).tolist(),
                "hd": maybe_downsample(getattr(leader.brain, "hd_cells", np.zeros_like(sim.brain.hd_cells)), 1).tolist() if leader else maybe_downsample(sim.brain.hd_cells, 1).tolist(),
            }

            stats_payload = {
                "frustration": getattr(leader, "frustration", 0.0),
                "score": getattr(leader, "score", 0),
                "status": "ALIVE" if leader and leader.deaths == 0 else "DEAD",
                "dopamine": getattr(leader, "dopamine_tonic", 0.0),
                "dopamine_tonic": getattr(leader, "dopamine_tonic", 0.0),
                "dopamine_phasic": getattr(leader, "dopamine_phasic", 0.0),
                "panic": float(getattr(leader, "panic", 0.0)) if leader else 0.0,
                "cortisol": float(getattr(leader, "cortisol", 0.0)) if leader else 0.0,
                "mode": "TOURNAMENT",
                "energy": 1.0,
                "atp": 1.0,
                "deaths": getattr(leader, "deaths", 0),
                "generation": sim.generation,
                "serotonin": getattr(leader, "serotonin", 0.0),
                "norepinephrine": 0.0,
                "ne_phasic": 0.0,
                "drive_pressure": 0.0,
                "lc_mode": "ARENA",
                "ne_uncertainty": 0.0,
                "ach_tonic": 0.0,
                "ach_mode": "BALANCED",
                "place_nav_mag": 0.0,
                "place_act_max": 0.0,
                "place_goal_strength": 0.0,
                "mt_theta_readouts": {},
                "mt_soma_readouts": {},
                "mt_plasticity_mult": 0.0,
                "mt_gate_thr": 0.0,
                "map_size": sim.map_size,
                "trn_modes": [],
                "wm": {
                    "slots": 0,
                    "write_threshold": 0.0,
                    "decay_rate": 0.0,
                    "motor_gain": 0.0,
                    "bias_vec": [],
                    "slot_strengths": [],
                },
                "pp": {
                    "pe_norm": 0.0,
                    "pe_ema": 0.0,
                    "yhat_next": [0.0] * 6,
                },
            }

            leader_whisk = leader.whisk_angle if leader else sim.whisk_angle
            leader_hits = leader.whisker_hits if leader else sim.whisker_hits
            leader_vision = leader.vision_buffer if leader else sim.vision_buffer
            leader_pos = leader.pos.tolist() if leader else sim.rat_pos.tolist()

            # Build pheromone trail from all agents for visualization
            sim.pheromones.extend([[float(a.pos[0]), float(a.pos[1])] for a in sim.tournament.agents if a.deaths == 0])
            sim.pheromones = sim.pheromones[-500:]

            return jsonify(
                {
                    "rat": leader_pos,
                    "tournament_rats": tournament_rats,
                    "targets": [t.tolist() for t in sim.targets],
                    "predators": [p.pos.tolist() for p in sim.tournament.predators],
                    "brain": brain_payload,
                    "stats": stats_payload,
                    "pheromones": sim.pheromones,
                    "whiskers": {"angle": leader_whisk, "hits": leader_hits},
                    "vision": leader_vision,
                    "tournament_status": tournament_status,
                }
            )

        for i in range(iterations):
            if sim.lab.active:
                sim.lab.step()
                # Override standard dying logic during experiment
                if sim.lab.active:
                    sim.brain.astrocyte.glycogen = 1.0

            sim.update_whiskers()
            sim.process_vision()
            sim.frames_alive += 1

            current_atp = float(sim.brain.astrocyte.neuronal_atp)
            dist_cat = float(np.linalg.norm(sim.rat_pos - sim.predator.pos))
            
            if current_atp <= 0.01 or dist_cat < 1.0:
                sim.die()
                return jsonify(
                    {
                        "rat": sim.rat_pos.tolist(),
                        "targets": [t.tolist() for t in sim.targets],
                        "predator": sim.predator.pos.tolist(),
                        "brain": {},
                        "stats": {
                        "frustration": 0,
                        "score": sim.score,
                        "status": "DEAD",
                        "dopamine": sim.dopamine_ema,
                        "dopamine_tonic": sim.dopamine_tonic,
                        "dopamine_phasic": sim.dopamine_phasic,
                        "panic": float(sim.panic),
                        "cortisol": float(sim.cortisol),
                        "mode": sim.behaviour_mode,
                        "energy": 0,
                        "atp": 0,
                            "deaths": sim.deaths,
                            "generation": sim.generation,
                        },
                        "reset_visuals": True,
                        "whiskers": {"angle": sim.whisk_angle, "hits": sim.whisker_hits},
                        "vision": sim.vision_buffer,
                    }
                )

            # Head direction update needs to happen before TRN modes are checked
            new_heading = float(np.arctan2(sim.rat_vel[1], sim.rat_vel[0]))
            angular_velocity = new_heading - sim.rat_heading
            if angular_velocity > np.pi:
                angular_velocity -= 2 * np.pi
            if angular_velocity < -np.pi:
                angular_velocity += 2 * np.pi
            sim.rat_heading = new_heading

            sim.brain.update_hd_cells(angular_velocity)
            head_direction = sim.brain.get_head_direction()

            danger_level = 0.0
            if dist_cat < 10.0:
                danger_level = 1.0 - (dist_cat / 10.0)

            near_death = dist_cat < 2.0

            # --- NEW: LC / Panic computation ---
            panic_gain = float(sim.config.get("panic_gain", 1.0))
            atp = float(sim.brain.astrocyte.neuronal_atp)
            atp_factor = 1.0 - clamp(atp / 1.0, 0.0, 1.0)
            panic_input = clamp(danger_level * (1.0 + atp_factor), 0.0, 2.0)
            tau_panic = -BASE_DT / np.log(0.9)
            alpha_panic = 1.0 - np.exp(-dt / tau_panic)
            sim.panic = sim.panic + alpha_panic * (panic_input - sim.panic)
            panic_signal = sim.panic * panic_gain

            # --- NEW: Cortisol update (slow stress hormone) ---
            cort_gain = float(sim.config.get("cortisol_gain", 0.5))
            cort_decay = float(sim.config.get("cortisol_decay", 0.005))
            sim.cortisol += cort_gain * panic_input * 0.01 * dt_scale
            sim.cortisol -= cort_decay * dt_scale
            sim.cortisol = clamp(sim.cortisol, 0.0, 2.0)

            # --- NEW: Behavioural mode classification ---
            if panic_signal < 0.2 and danger_level < 0.2:
                sim.behaviour_mode = "SAFE"
            elif panic_signal < 0.7 and danger_level < 0.8:
                sim.behaviour_mode = "ALERT"
            else:
                sim.behaviour_mode = "PANIC"
            if sim.cortisol > 0.5 and sim.behaviour_mode == "SAFE":
                sim.behaviour_mode = "ALERT"

            # ---- PRECOMPUTE TRN MODES ----
            # This is the new logic to pre-compute TRN modes
            w_amyg = clamp(sim.brain.weights.get("amygdala", 1.0), 0.1, 10.0)
            w_hip = clamp(sim.brain.weights.get("hippocampus", 1.0), 0.1, 10.0)
            fear_gain = float(sim.config.get("fear_gain", 1.0))

            # Precompute touch
            touch_now = 1.0 if (sim.whisker_hits and any(sim.whisker_hits)) else 0.0
            arousal_from_touch = touch_now * 0.1

            # Precompute collision
            next_x_pos = np.array([sim.rat_pos[0] + sim.rat_vel[0] * dt_scale, sim.rat_pos[1]])
            next_y_pos = np.array([sim.rat_pos[0], sim.rat_pos[1] + sim.rat_vel[1] * dt_scale])
            pred_hit_x = sim.check_collision(next_x_pos)
            pred_hit_y = sim.check_collision(next_y_pos)
            collision_predicted = pred_hit_x or pred_hit_y
            pain_now = 1.0 if collision_predicted else 0.0

            # Precompute reward
            reward_signal = 0.0
            for idx, target_pos in enumerate(sim.targets):
                if float(np.linalg.norm(sim.rat_pos - target_pos)) < 1.0:
                    reward_signal = 1.0
                    break

            # Precompute LC output
            novelty_for_lc = 0.0
            enable_sensory_cortex = float(sim.config.get("enable_sensory_cortex", 0.0)) > 0.5
            # Estimate novelty from vision buffer (targets closer = higher salience)
            current_salience = 0.0
            for ray in sim.vision_buffer:
                if ray.get("type") == 3:  # Target
                    current_salience = max(current_salience, 1.0 / (ray.get("dist", 0.0) + 1.0))
            if not hasattr(sim, "prev_salience_for_lc"):
                sim.prev_salience_for_lc = 0.0
            novelty_for_lc = abs(current_salience - sim.prev_salience_for_lc)
            sim.prev_salience_for_lc = 0.9 * sim.prev_salience_for_lc + 0.1 * current_salience
            novelty_for_lc = clamp(novelty_for_lc, 0.0, 1.0)

            surprise_for_lc = 0.0
            if float(sim.config.get("enable_predictive_processing", 0.0)) > 0.5:
                surprise_for_lc = float(sim.brain.last_pp.get("pe_norm", 0.0)) * float(sim.config.get("pp_surprise_gain", 1.0))

            raw_sensory_inputs = {
                "novelty": novelty_for_lc,
                "pain": pain_now,
                "touch": float(sim.last_touch) if hasattr(sim, "last_touch") else 0.0,
                "surprise": surprise_for_lc,
                "danger": float(danger_level),
            }
            sim.brain.orchestrator.step(dt, raw_sensory_inputs, float(reward_signal))
            nm = sim.brain.orchestrator.neuromod
            lc_out = {
                "arousal_boost": nm.arousal_boost,
                "attention_gain": nm.attention_gain,
                "explore_gain": nm.explore_gain,
                "plasticity_gain": nm.plasticity_gain,
                "habit_weight": nm.habit_weight,
                "deliberation_weight": nm.deliberation_weight,
                "wm_stability": nm.wm_stability,
                "attention_breadth": nm.attention_breadth,
            }
            
            phasic_arousal = clamp(sim.dopamine_phasic, 0.0, 1.0) * 0.5
            arousal = phasic_arousal + (sim.frustration * 0.5) + arousal_from_touch + lc_out["arousal_boost"] + (0.3 * panic_signal)
            if current_atp < 0.2:
                arousal = 0.0

            safety_bias = 0.5 + (sim.serotonin * 1.0)
            amygdala_drive = float(danger_level) * w_amyg * fear_gain * safety_bias
            amygdala_drive *= (1.0 + 0.2 * panic_signal)
            pfc_drive = float(sim.frustration) * w_hip

            trn_modes = sim.brain.trn.step(arousal, amygdala_drive, pfc_drive, dt=dt)
            # ---- END PRECOMPUTE ----

            # If both in burst: return microsleep on final iteration
            if trn_modes[0] == "BURST" and trn_modes[1] == "BURST":
                if i == iterations - 1:
                    panic_trn_gain_ms = float(sim.config.get("panic_trn_gain", 0.5))
                    
                    target_pos = None
                    if len(sim.targets) > 0:
                        target_pos = sim.targets[0]
                        min_dist = np.linalg.norm(sim.rat_pos - target_pos)
                        for t in sim.targets[1:]:
                            dist = np.linalg.norm(sim.rat_pos - t)
                            if dist < min_dist:
                                min_dist = dist
                                target_pos = t

                    # UPDATE UNPACKING: Add internal dopamine (total + phasic) at the end
                    cfg_ms = dict(sim.config)
                    # Disable PP during microsleep to prevent replay/dream content from corrupting the world model
                    cfg_ms["enable_predictive_processing"] = 0.0
                    soma_density, d_theta, d_grid, final_decision, glycogen_level, atp_level, _, _, place_metrics, soma_r, theta_r, mt_plasticity_mult, mt_gate_thr, internal_dopamine, internal_dopamine_phasic = sim.brain.process_votes(
                        sim.frustration,
                        sim.dopamine_tonic,
                        sim.rat_vel,
                        0,
                        0,
                        len(sim.pheromones),
                        head_direction,
                        sim.vision_buffer,
                        anesthetic_level=anesthetic_level,
                        extra_arousal=arousal_from_touch,
                        rat_pos=sim.rat_pos,
                        panic=panic_signal,
                        cortisol=sim.cortisol,
                        near_death=near_death,
                        panic_trn_gain=panic_trn_gain_ms,
                        replay_len=int(sim.config.get("replay_len", 240)),
                        dt=dt,
                        precomputed_trn_modes=trn_modes,
                        arousal=arousal,
                        amygdala_drive=amygdala_drive,
                        pfc_drive=pfc_drive,
                        target_pos=target_pos,
                        config=cfg_ms,
                        map_size=sim.map_size,
                        predator_pos=sim.predator.pos,
                        serotonin=sim.serotonin,
                    )
                    # Update dopamine state even during microsleep
                    # --- VISUALIZE INTERNAL DOPAMINE ---
                    # Smooth total dopamine (tonic + phasic) for display; derive phasic component explicitly
                    sim.dopamine_phasic = float(internal_dopamine - sim.dopamine_tonic)
                    sim.dopamine_ema = 0.8 * sim.dopamine_ema + 0.2 * clamp(float(internal_dopamine), -1.0, 1.0)

                    # --- OFFLINE HIPPOCAMPAL REPLAY ---
                    if float(sim.config.get("enable_replay", 0.0)) > 0.5 and sim.brain.last_bf.get("mode", "BALANCED") != "ENCODING":
                        sim.brain.replay.set_capacity(int(sim.config.get("replay_len", 240)))
                        sim.brain.offline_replay_and_consolidate(
                            steps=int(sim.config.get("replay_steps", 6)),
                            bridge_prob=float(sim.config.get("replay_bridge_prob", 0.25)),
                            strength=float(sim.config.get("replay_strength", 0.15)),
                            stress_learning_gain=float(sim.config.get("stress_learning_gain", 0.5)),
                        )
                        sim.phantom_trace = sim.brain.replay.last_replay_trace[-200:]
                    current_walls = None
                    if sim.lab.active:
                        current_walls = []
                        for y in range(sim.map_size):
                            for x in range(sim.map_size):
                                if sim.occupancy_grid[y, x] == 1:
                                    current_walls.append([x, y, 1, 1])

                    return jsonify(
                        {
                            "rat": sim.rat_pos.tolist(),
                            "walls": current_walls,
                            "targets": [t.tolist() for t in sim.targets],
                            "predator": sim.predator.pos.tolist(),
                            "brain": serialize_state(soma_density, d_theta, d_grid, downsample),
                            "cerebellum": {
                                "predicted_pos": sim.cerebellum.predicted_pos.tolist(),
                                "correction_vector": sim.cerebellum.correction_vector.tolist(),
                            },
                            "stats": {
                    # --- CORE METRICS ---
                    "frustration": sim.frustration,
                    "score": sim.score,
                    "status": "MICROSLEEP",
                    "energy": float(glycogen_level),
                    "atp": float(atp_level),
                    "deaths": sim.deaths,
                    "generation": sim.generation,
                    
                    # --- NEUROMODULATORS (WIRED TO ORCHESTRATOR) ---
                    "dopamine": sim.dopamine_ema,
                    "dopamine_tonic": sim.dopamine_tonic,
                    "dopamine_phasic": sim.dopamine_phasic,
                    "serotonin": sim.serotonin,
                    
                    # LC (Norepinephrine) - Read from Diagnostics
                    "norepinephrine": float(sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("tonic_ne", 0.0)),
                    "ne_phasic": float(sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("phasic_ne", 0.0)),
                    "ne_uncertainty": float(sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("uncertainty", 0.0)),
                    "ne_mode": sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("mode", "EXPLOIT"),
                    "lc_mode": sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("mode", "EXPLOIT"),
                    
                    # ACh (Basal Forebrain) - Read from Diagnostics
                    "ach_tonic": float(sim.brain.orchestrator.last_diagnostics.get("basal_forebrain", {}).get("tonic_ach", 0.0)),
                    "ach_mode": sim.brain.orchestrator.last_diagnostics.get("basal_forebrain", {}).get("mode", "BALANCED"),
                    "ach_precision_gain": float(sim.brain.orchestrator.last_diagnostics.get("basal_forebrain", {}).get("precision_gain", 0.0)),

                    # Sensory / Boredom - Read from Diagnostics
                    "boredom": float(sim.brain.orchestrator.last_diagnostics.get("vision_cortex", {}).get("boredom", 0.0)),
                    
                    # --- STRESS ---
                    "panic": float(panic_signal),
                    "cortisol": float(sim.cortisol),
                    "mode": sim.behaviour_mode,

                    # --- LEGACY / OTHER ---
                    "place_nav_mag": place_metrics["place_nav_mag"],
                    "place_act_max": place_metrics["place_act_max"],
                    "place_goal_strength": place_metrics["place_goal_strength"],
                    "mt_theta_readouts": theta_r,
                    "mt_soma_readouts": soma_r,
                    "mt_plasticity_mult": mt_plasticity_mult,
                    "mt_gate_thr": mt_gate_thr,
                    "map_size": sim.map_size,
                    "trn_modes": list(getattr(sim.brain.trn, "modes", [])),
                    "wm": {
                        "slots": len(sim.brain.wm_slots),
                        "write_threshold": float(sim.brain.wm_write_threshold),
                        "decay_rate": float(sim.brain.wm_decay_rate),
                        "motor_gain": float(sim.brain.wm_motor_gain),
                        "bias_vec": sim.brain.last_wm_bias.tolist(),
                        "slot_strengths": [float(s.get("strength", 0.0)) for s in getattr(sim.brain, "wm_slots", [])],
                    },
                    "pp": {
                        "pe_norm": float(sim.brain.last_pp.get("pe_norm", 0.0)),
                        "pe_ema": float(sim.brain.last_pp.get("pe_ema", 0.0)),
                        "yhat_next": sim.brain.last_pp.get("yhat_next", np.zeros(6)).tolist(),
                    },
                },
                            "phantom": sim.phantom_trace,
                            "pheromones": sim.pheromones,
                            "whiskers": {"angle": sim.whisk_angle, "hits": sim.whisker_hits},
                            "vision": sim.vision_buffer,
                        }
                    )
                continue

            # Reward detection
            reward_signal = 0.0
            if sim.lab.active:
                # Lab protocols set a flag when success occurs; do not respawn targets here
                if getattr(sim, "lab_reward_flag", False):
                    reward_signal = 1.0
                    sim.lab_reward_flag = False
            else:
                for idx, target_pos in enumerate(sim.targets):
                    if float(np.linalg.norm(sim.rat_pos - target_pos)) < 1.0:
                        sim.score += 1
                        sim.frustration = 0.0
                        # Tonic dopamine slowly increases with repeated success; cap at 0.5
                        sim.dopamine_tonic = clamp(sim.dopamine_tonic + 0.125, 0.0, 0.5)
                        sim.brain.astrocyte.glycogen = 1.0
                        reward_signal = 1.0
                        sim.targets[idx] = sim._spawn_single_target()
                        break
            
            # NOTE: head direction is now computed above the microsleep check

            # --- PREDICTIVE COLLISION ---
            next_x_pos = np.array([sim.rat_pos[0] + sim.rat_vel[0] * dt_scale, sim.rat_pos[1]])
            next_y_pos = np.array([sim.rat_pos[0], sim.rat_pos[1] + sim.rat_vel[1] * dt_scale])
            pred_hit_x = sim.check_collision(next_x_pos)
            pred_hit_y = sim.check_collision(next_y_pos)
            collision_predicted = pred_hit_x or pred_hit_y
            
            # Extract config settings
            cerebellum_gain = float(sim.config.get("cerebellum_gain", 1.0))
            memory_gain = float(sim.config.get("memory_gain", 1.0))
            fear_gain = float(sim.config.get("fear_gain", 1.0))
            use_energy = float(sim.config.get("energy_constraint", 1.0)) > 0.5
            panic_trn_gain = float(sim.config.get("panic_trn_gain", 0.5))
            panic_motor_bias = float(sim.config.get("panic_motor_bias", 0.5))
            stress_learning_gain = float(sim.config.get("stress_learning_gain", 0.5))
            
            collision_flag = collision_predicted

            sensory_blend = float(sim.config.get("sensory_blend", 0.0))
            enable_sensory_cortex = float(sim.config.get("enable_sensory_cortex", 0.0)) > 0.5
            enable_thalamus = float(sim.config.get("enable_thalamus", 0.0)) > 0.5

            target_pos = None
            if len(sim.targets) > 0:
                target_pos = sim.targets[0]
                min_dist = np.linalg.norm(sim.rat_pos - target_pos)
                for t in sim.targets[1:]:
                    dist = np.linalg.norm(sim.rat_pos - t)
                    if dist < min_dist:
                        min_dist = dist
                        target_pos = t

            # UPDATE UNPACKING: Add internal dopamine (total + phasic) at the end
            soma_density, d_theta, d_grid, final_decision, glycogen_level, atp_level, pain, touch, place_metrics, soma_r, theta_r, mt_plasticity_mult, mt_gate_thr, internal_dopamine, internal_dopamine_phasic = sim.brain.process_votes(
                sim.frustration,
                sim.dopamine_tonic,
                sim.rat_vel,
                reward_signal,
                danger_level,
                len(sim.pheromones),
                head_direction,
                sim.vision_buffer,
                anesthetic_level=anesthetic_level,
                # Pass new knobs
                fear_gain=fear_gain,
                memory_gain=memory_gain,
                energy_constraint=use_energy,
                whisker_hits=sim.whisker_hits,
                collision=collision_flag,
                sensory_blend=sensory_blend,
                enable_sensory_cortex=enable_sensory_cortex,
                enable_thalamus=enable_thalamus,
                extra_arousal=arousal_from_touch,
                rat_pos=sim.rat_pos,
                panic=panic_signal,
                cortisol=sim.cortisol,
                near_death=near_death,
                panic_trn_gain=panic_trn_gain,
                replay_len=int(sim.config.get("replay_len", 240)),
                dt=dt,
                precomputed_trn_modes=trn_modes,
                arousal=arousal,
                amygdala_drive=amygdala_drive,
                pfc_drive=pfc_drive,
                target_pos=target_pos,
                config=sim.config,
                map_size=sim.map_size,
                predator_pos=sim.predator.pos,
                serotonin=sim.serotonin,
            )
            sim.last_touch = touch # Update for next step

            # --- DOPAMINE STATE UPDATE ---
            sim.dopamine_phasic = float(internal_dopamine - sim.dopamine_tonic)
            target_dopa = clamp(float(internal_dopamine), -1.0, 1.0)
            sim.dopamine_ema = 0.8 * sim.dopamine_ema + 0.2 * target_dopa

            if panic_signal > 0.05 and panic_motor_bias > 0.0:
                diff = sim.rat_pos - sim.predator.pos
                dist = float(np.linalg.norm(diff))
                if dist > 1e-6:
                    flee_dir = diff / dist
                    panic_scale = clamp(panic_signal, 0.0, 1.0)
                    flee_boost = flee_dir * (0.1 * panic_motor_bias * panic_scale)
                    final_decision = final_decision + flee_boost

            sim.cerebellum.predict(sim.rat_pos, final_decision)
            
            # --- APPLY CEREBELLUM GAIN ---
            final_decision_corrected = final_decision + (sim.cerebellum.correction_vector * cerebellum_gain)

            sim.rat_vel = (sim.rat_vel * 0.85) + (final_decision_corrected * 0.15)
            sim.rat_vel = np.nan_to_num(sim.rat_vel)

            explore_gain = float(getattr(sim.brain, "lc", None).last.get("explore_gain", 1.0)) if hasattr(sim.brain, "lc") else 1.0
            if sim.config.get("mt_causal", 0.0) > 0.5:
                explore_gain *= (1.0 + sim.brain.mt_readout_theta * sim.config.get("mt_mod_explore", 0.3))
            impulsivity_factor = 1.0 + (1.0 - sim.serotonin) * 0.5
            tremor = sim.rng_noise.normal(0.0, 1.0, size=2) * 0.02 * explore_gain * impulsivity_factor
            sim.rat_vel += tremor

            s = float(np.linalg.norm(sim.rat_vel))
            total_dopamine = clamp(sim.dopamine_tonic + sim.dopamine_phasic, 0.0, 1.0)
            max_speed = 0.3 + (total_dopamine * 0.2)
            if s > max_speed:
                sim.rat_vel = (sim.rat_vel / (s + 1e-9)) * max_speed

            # --- NEW SLIDING PHYSICS LOGIC ---
            
            # 1. Try moving along X axis
            next_x_pos = np.array([sim.rat_pos[0] + sim.rat_vel[0] * dt_scale, sim.rat_pos[1]])
            hit_x = sim.check_collision(next_x_pos)
            
            if hit_x:
                sim.rat_vel[0] *= -0.5 # Bounce X
                # Friction on Y when hitting X wall
                sim.rat_vel[1] *= 0.9 
            else:
                sim.rat_pos[0] += sim.rat_vel[0] * dt_scale

            # 2. Try moving along Y axis
            next_y_pos = np.array([sim.rat_pos[0], sim.rat_pos[1] + sim.rat_vel[1] * dt_scale])
            hit_y = sim.check_collision(next_y_pos)
            
            if hit_y:
                sim.rat_vel[1] *= -0.5 # Bounce Y
                # Friction on X when hitting Y wall
                sim.rat_vel[0] *= 0.9
            else:
                sim.rat_pos[1] += sim.rat_vel[1] * dt_scale

        # 3. Update Status
        sim.last_collision = hit_x or hit_y
        
        # --- TONIC DOPAMINE DYNAMICS ---
        # Tonic dopamine slowly drifts toward baseline or depletes under stress
        if sim.frustration < 0.1:
            target_tonic = 0.2
            recovery_rate = 0.001
            sim.dopamine_tonic += (target_tonic - sim.dopamine_tonic) * recovery_rate
        else:
            stress_depletion = 0.0005 * sim.frustration
            sim.dopamine_tonic -= stress_depletion
        sim.dopamine_tonic = clamp(sim.dopamine_tonic, -0.3, 0.5)

        # --- SEROTONIN DYNAMICS ---
        # Chronic stress (cortisol) depletes serotonin; calm periods allow slow recovery.
        if sim.cortisol > 0.5:
            depletion_rate = 0.002 * (sim.cortisol - 0.5)
            sim.serotonin -= depletion_rate * dt_scale

        acute_stressors = sim.frustration + (pain * 0.5)
        if acute_stressors > 0.1:
            acute_depletion = 0.001 * acute_stressors
            sim.serotonin -= acute_depletion * dt_scale

        if sim.frustration < 0.1 and sim.cortisol < 0.3:
            recovery_target = 0.8
            recovery_rate = 0.0005
            sim.serotonin += (recovery_target - sim.serotonin) * recovery_rate * dt_scale

        if reward_signal > 0:
            sim.serotonin = min(1.0, sim.serotonin + 0.02)

        sim.serotonin = clamp(sim.serotonin, 0.0, 1.0)

        if sim.last_collision:
            frustration_sensitivity = 1.0 + (1.0 - sim.serotonin) * 1.5
            frustration_gain = 0.1 * frustration_sensitivity
            sim.frustration = min(1.0, sim.frustration + frustration_gain)
        else:
            decay_rate = 0.005 * (0.5 + 0.5 * sim.serotonin)
            sim.frustration = max(0.0, sim.frustration - decay_rate * dt_scale)

        # Pain increases frustration
        if pain > 0:
            pain_sensitivity = 1.0 + (1.0 - sim.serotonin) * 0.5
            sim.frustration = min(1.0, sim.frustration + pain * 0.05 * pain_sensitivity)

        # --- SEROTONIN GIVE-UP THRESHOLD ---
        if sim.frustration > 0.7:
            give_up_prob = (1.0 - sim.serotonin) * 0.3
            if sim.rng_noise.random() < give_up_prob:
                sim.dopamine_tonic = max(-0.3, sim.dopamine_tonic - 0.1)
                sim.frustration = max(0.5, sim.frustration - 0.2)

        sim.rat_pos = finite_or_zero(sim.rat_pos)
        sim.rat_vel = finite_or_zero(sim.rat_vel)

        sim.cerebellum.update(sim.rat_pos)

        # Only hunt if we aren't doing a science experiment, unless the protocol is survival
        allow_hunt = (not sim.lab.active) or (sim.lab.active and isinstance(sim.lab.protocol, SurvivalProtocol))
        if allow_hunt:
            sim.predator.hunt(sim.rat_pos, sim.rat_vel, sim.occupancy_grid, sim.map_size, dt_scale=dt_scale)

        base_p = 0.2
        p_drop = 1.0 - (1.0 - base_p) ** dt_scale
        if sim.rng_noise.random() < p_drop:
            sim.pheromones.append(sim.rat_pos.tolist())
            if len(sim.pheromones) > 1000:
                sim.pheromones.pop(0)

        current_walls = None
        if sim.lab.active:
            current_walls = []
            for y in range(sim.map_size):
                for x in range(sim.map_size):
                    if sim.occupancy_grid[y, x] == 1:
                        current_walls.append([x, y, 1, 1])

        # Return last-frame state
        return jsonify(
            {
                "rat": sim.rat_pos.tolist(),
                "walls": current_walls,
                "targets": [t.tolist() for t in sim.targets],
                "predator": sim.predator.pos.tolist(),
                "brain": serialize_state(soma_density, d_theta, d_grid, downsample),
                "cerebellum": {
                    "predicted_pos": sim.cerebellum.predicted_pos.tolist(),
                    "correction_vector": sim.cerebellum.correction_vector.tolist(),
                },
                "stats": {
                    # --- CORE METRICS ---
                    "frustration": sim.frustration,
                    "score": sim.score,
                    "status": "AWAKE" if "TONIC" in sim.brain.trn.modes else "MICROSLEEP",
                    "energy": float(glycogen_level),
                    "atp": float(atp_level),
                    "deaths": sim.deaths,
                    "generation": sim.generation,
                    
                    # --- NEUROMODULATORS (WIRED TO ORCHESTRATOR) ---
                    "dopamine": sim.dopamine_ema,
                    "dopamine_tonic": sim.dopamine_tonic,
                    "dopamine_phasic": sim.dopamine_phasic,
                    "serotonin": sim.serotonin,
                    
                    # LC (Norepinephrine) - Read from Diagnostics
                    "norepinephrine": float(sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("tonic_ne", 0.0)),
                    "ne_phasic": float(sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("phasic_ne", 0.0)),
                    "ne_uncertainty": float(sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("uncertainty", 0.0)),
                    "ne_mode": sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("mode", "EXPLOIT"),
                    "lc_mode": sim.brain.orchestrator.last_diagnostics.get("locus_coeruleus", {}).get("mode", "EXPLOIT"),
                    
                    # ACh (Basal Forebrain) - Read from Diagnostics
                    "ach_tonic": float(sim.brain.orchestrator.last_diagnostics.get("basal_forebrain", {}).get("tonic_ach", 0.0)),
                    "ach_mode": sim.brain.orchestrator.last_diagnostics.get("basal_forebrain", {}).get("mode", "BALANCED"),
                    "ach_precision_gain": float(sim.brain.orchestrator.last_diagnostics.get("basal_forebrain", {}).get("precision_gain", 0.0)),

                    # Sensory / Boredom - Read from Diagnostics
                    "boredom": float(sim.brain.orchestrator.last_diagnostics.get("vision_cortex", {}).get("boredom", 0.0)),
                    
                    # --- STRESS ---
                    "panic": float(panic_signal),
                    "cortisol": float(sim.cortisol),
                    "mode": sim.behaviour_mode,

                    # --- LEGACY / OTHER ---
                    "place_nav_mag": place_metrics["place_nav_mag"],
                    "mt_theta_readouts": theta_r,
                    "mt_soma_readouts": soma_r,
                    "mt_plasticity_mult": mt_plasticity_mult,
                    "mt_gate_thr": mt_gate_thr,
                    "map_size": sim.map_size,
                    "trn_modes": list(getattr(sim.brain.trn, "modes", [])),
                    "wm": {
                        "slots": len(sim.brain.wm_slots),
                        "write_threshold": float(sim.brain.wm_write_threshold),
                        "decay_rate": float(sim.brain.wm_decay_rate),
                        "motor_gain": float(sim.brain.wm_motor_gain),
                        "bias_vec": sim.brain.last_wm_bias.tolist(),
                        "slot_strengths": [float(s.get("strength", 0.0)) for s in getattr(sim.brain, "wm_slots", [])],
                    },
                    "pp": {
                        "pe_norm": float(sim.brain.last_pp.get("pe_norm", 0.0)),
                        "pe_ema": float(sim.brain.last_pp.get("pe_ema", 0.0)),
                        "yhat_next": sim.brain.last_pp.get("yhat_next", np.zeros(6)).tolist(),
                    },
                },
                "pheromones": sim.pheromones,
                "whiskers": {"angle": sim.whisk_angle, "hits": sim.whisker_hits},
                "vision": sim.vision_buffer,
            }
        )


@app.route("/lab/start", methods=["POST"])
def start_lab():
    with sim_lock:
        req = request.json or {}
        test_type = req.get("test_id", "open_field")
        
        # Extract custom config if present
        custom_config = req.get("custom_config", None)
        
        sim.lab.start_experiment(test_type, custom_config)
        
        # ... existing wall generation code ...
        walls = [] 
        for y in range(sim.map_size):
            for x in range(sim.map_size):
                if sim.occupancy_grid[y, x] == 1:
                    walls.append([x, y, 1, 1])
                    
        return jsonify({"status": "started", "test": test_type, "walls": walls})


@app.route("/lab/stop", methods=["POST"])
def stop_lab():
    with sim_lock:
        sim.lab.stop_experiment()
        sim.generate_map()
        return jsonify({"status": "stopped"})


@app.route("/tournament/start", methods=["POST"])
def start_tournament():
    with sim_lock:
        sim.tournament.start_tournament()
        sim.frames_alive = 0
        # Reset environment targets/trails for arena play
        sim.targets = [sim._spawn_single_target() for _ in range(3)]
        sim.pheromones = []
        if hasattr(sim, "predator"):
            sim.predator.pos = np.array([float(sim.map_size - 5), 3.0])
        return jsonify({"status": "started"})


@app.route("/lab/results", methods=["GET"])
def lab_results():
    with sim_lock:
        return jsonify(sim.lab.get_results())


@app.route("/history", methods=["GET"])
def history():
    with sim_lock:
        data = []
        if float(sim.config.get("deterministic", 0.0)) > 0.5:
            return jsonify(data)
        if os.path.exists("evolution_log.csv"):
            with open("evolution_log.csv", "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    data.append(row)
        return jsonify(data)


@app.route("/load_generation", methods=["POST"])
def load_generation():
    with sim_lock:
        payload = request.json or {}
        gen_id = str(payload.get("generation"))

        if float(sim.config.get("deterministic", 0.0)) > 0.5:
            return jsonify({"status": "error", "msg": "Deterministic mode: load disabled"}), 400

        if os.path.exists("evolution_log.csv"):
            with open("evolution_log.csv", "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row["Generation"] == gen_id:
                        sim.brain.weights["amygdala"] = float(row["Amygdala"])
                        sim.brain.weights["striatum"] = float(row["Striatum"])
                        sim.brain.weights["hippocampus"] = float(row["Hippocampus"])

                        sim.generate_map()
                        sim.deaths = 0

                        walls = []
                        for y in range(sim.map_size):
                            for x in range(sim.map_size):
                                if sim.occupancy_grid[y, x] == 1:
                                    walls.append([x, y, 1, 1])

                        return jsonify({"status": "loaded", "gen": gen_id, "walls": walls})

        return jsonify({"status": "error", "msg": "Gen not found"}), 404


@app.route("/reset", methods=["POST"])
def reset():
    with sim_lock:
        sim.generate_map()
        sim.frustration = 0
        sim.dopamine_ema = 0.2
        sim.dopamine_tonic = 0.2
        sim.dopamine_phasic = 0.0
        sim.serotonin = 0.5
        sim.deaths = 0
        sim.generation = 1

        if not (float(sim.config.get("deterministic", 0.0)) > 0.5):
            with open("evolution_log.csv", "w") as f:
                f.write("Generation,Fitness,Amygdala,Striatum,Hippocampus\n")

        walls = []
        for y in range(sim.map_size):
            for x in range(sim.map_size):
                if sim.occupancy_grid[y, x] == 1:
                    walls.append([x, y, 1, 1])

        return jsonify({"status": "reset", "walls": walls})


@app.route("/config", methods=["POST"])
def config():
    with sim_lock:
        payload = request.json or {}

        prev_det = float(sim.config.get("deterministic", 0.0))
        prev_seed = sim.config.get("seed")

        # Detect Architecture Change
        prev_mt_type = sim.config.get("coherence_field_type", "microtubule")
        
        # Update config dictionary from payload
        if "coherence_field_type" in payload:
             sim.config["coherence_field_type"] = payload["coherence_field_type"]

        # Check if we need to rebuild the brain
        new_mt_type = sim.config.get("coherence_field_type", "microtubule")
        
        if prev_mt_type != new_mt_type:
            print(f"ARCH: Switching Microtubules from {prev_mt_type} to {new_mt_type}...")
            # Re-initialize the brain with the new factory setting
            saved_weights = {"w_gate": sim.brain.basal_ganglia.w_gate.copy(), "w_motor": sim.brain.basal_ganglia.w_motor.copy(), "genome": sim.brain.weights.copy()}
            sim.brain = DendriticCluster(
                config=sim.config, 
                rng=sim.rng_brain, 
                py_rng=sim.py_rng, 
                mt_rng=sim.rng_microtub, 
                load_genome=True,
                preserve_weights=saved_weights
            )

        # Validate & clamp
        if "speed" in payload:
            sim.config["speed"] = int(np.clip(int(payload["speed"]), 1, int(sim.config.get("max_speed", 10))))
        if "max_speed" in payload:
            sim.config["max_speed"] = int(np.clip(int(payload["max_speed"]), 1, 200))
            sim.config["speed"] = int(np.clip(int(sim.config["speed"]), 1, sim.config["max_speed"]))
        if "dt" in payload:
            sim.config["dt"] = clamp(float(payload["dt"]), 0.001, 1.0)
        if "sensitivity" in payload:
            sim.config["sensitivity"] = clamp(float(payload["sensitivity"]), 0.001, 1.0)
        if "anesthetic" in payload:
            sim.config["anesthetic"] = clamp(float(payload["anesthetic"]), 0.0, 1.0)
        if "downsample" in payload:
            sim.config["downsample"] = int(np.clip(int(payload["downsample"]), 1, 8))

        # Add new checks
        if "cerebellum_gain" in payload:
            sim.config["cerebellum_gain"] = clamp(float(payload["cerebellum_gain"]), 0.0, 5.0)
        if "memory_gain" in payload:
            sim.config["memory_gain"] = clamp(float(payload["memory_gain"]), 0.0, 5.0)
        if "fear_gain" in payload:
            sim.config["fear_gain"] = clamp(float(payload["fear_gain"]), 0.0, 10.0)
        if "dopamine_tonic" in payload:
            sim.config["dopamine_tonic"] = clamp(float(payload["dopamine_tonic"]), -0.3, 0.8)
        if "energy_constraint" in payload:
            sim.config["energy_constraint"] = clamp(float(payload["energy_constraint"]), 0.0, 1.0)

        if "enable_sensory_cortex" in payload:
            sim.config["enable_sensory_cortex"] = clamp(float(payload["enable_sensory_cortex"]), 0.0, 1.0)
        if "enable_thalamus" in payload:
            sim.config["enable_thalamus"] = clamp(float(payload["enable_thalamus"]), 0.0, 1.0)
        if "sensory_blend" in payload:
            sim.config["sensory_blend"] = clamp(float(payload["sensory_blend"]), 0.0, 1.0)
        if "enable_replay" in payload:
            sim.config["enable_replay"] = clamp(float(payload["enable_replay"]), 0.0, 1.0)
        if "replay_steps" in payload:
            sim.config["replay_steps"] = int(np.clip(int(payload["replay_steps"]), 0, 50))
        if "replay_len" in payload:
            sim.config["replay_len"] = int(np.clip(int(payload["replay_len"]), 10, 5000))
        if "replay_strength" in payload:
            sim.config["replay_strength"] = clamp(float(payload["replay_strength"]), 0.0, 2.0)
        if "replay_bridge_prob" in payload:
            sim.config["replay_bridge_prob"] = clamp(float(payload["replay_bridge_prob"]), 0.0, 1.0)
        if "mt_neighbor_mode" in payload:
            mode = str(payload["mt_neighbor_mode"]).lower()
            sim.config["mt_neighbor_mode"] = mode if mode in {"legacy", "canonical"} else "legacy"
        if "seed" in payload:
            sim.config["seed"] = None if payload["seed"] in (None, "", "none") else int(payload["seed"])
        if "deterministic" in payload:
            sim.config["deterministic"] = clamp(float(payload["deterministic"]), 0.0, 1.0)
        if "panic_gain" in payload:
            sim.config["panic_gain"] = clamp(float(payload["panic_gain"]), 0.0, 5.0)
        if "cortisol_gain" in payload:
            sim.config["cortisol_gain"] = clamp(float(payload["cortisol_gain"]), 0.0, 5.0)
        if "cortisol_decay" in payload:
            sim.config["cortisol_decay"] = clamp(float(payload["cortisol_decay"]), 0.0, 0.1)
        if "panic_trn_gain" in payload:
            sim.config["panic_trn_gain"] = clamp(float(payload["panic_trn_gain"]), 0.0, 5.0)
        if "panic_motor_bias" in payload:
            sim.config["panic_motor_bias"] = clamp(float(payload["panic_motor_bias"]), 0.0, 5.0)
        if "stress_learning_gain" in payload:
            sim.config["stress_learning_gain"] = clamp(float(payload["stress_learning_gain"]), 0.0, 5.0)
        if "enable_predictive_processing" in payload:
            sim.config["enable_predictive_processing"] = clamp(float(payload["enable_predictive_processing"]), 0.0, 1.0)
        if "pp_lr" in payload:
            sim.config["pp_lr"] = clamp(float(payload["pp_lr"]), 0.0, 1.0)
        if "pp_weight_decay" in payload:
            sim.config["pp_weight_decay"] = clamp(float(payload["pp_weight_decay"]), 0.0, 1.0)
        if "pp_error_tau" in payload:
            sim.config["pp_error_tau"] = clamp(float(payload["pp_error_tau"]), 0.0, 10.0)
        if "pp_surprise_gain" in payload:
            sim.config["pp_surprise_gain"] = clamp(float(payload["pp_surprise_gain"]), 0.0, 5.0)
        if "pp_explore_gain" in payload:
            sim.config["pp_explore_gain"] = clamp(float(payload["pp_explore_gain"]), 0.0, 5.0)
        if "pp_error_scale" in payload:
            sim.config["pp_error_scale"] = clamp(float(payload["pp_error_scale"]), 0.0, 10.0)
        # Place cell knobs
        if "enable_place_cells" in payload:
            sim.config["enable_place_cells"] = clamp(float(payload["enable_place_cells"]), 0.0, 1.0)
        if "place_n" in payload:
            sim.config["place_n"] = int(np.clip(int(payload["place_n"]), 16, 1024))
        if "place_sigma" in payload:
            sim.config["place_sigma"] = clamp(float(payload["place_sigma"]), 0.5, 5.0)
        if "place_lr" in payload:
            sim.config["place_lr"] = clamp(float(payload["place_lr"]), 0.0, 0.5)
        if "place_decay" in payload:
            sim.config["place_decay"] = clamp(float(payload["place_decay"]), 0.0, 0.1)
        if "place_goal_lr" in payload:
            sim.config["place_goal_lr"] = clamp(float(payload["place_goal_lr"]), 0.0, 0.5)
        if "place_nav_gain" in payload:
            sim.config["place_nav_gain"] = clamp(float(payload["place_nav_gain"]), 0.0, 5.0)
        if "goal_reward_threshold" in payload:
            sim.config["goal_reward_threshold"] = clamp(float(payload["goal_reward_threshold"]), 0.0, 1.0)
        # --- WORKING MEMORY ---
        if "wm_slots" in payload:
            sim.config["wm_slots"] = int(np.clip(int(payload["wm_slots"]), 1, 10))
        if "wm_write_threshold" in payload:
            sim.config["wm_write_threshold"] = clamp(float(payload["wm_write_threshold"]), 0.0, 1.0)
        if "wm_decay_rate" in payload:
            sim.config["wm_decay_rate"] = clamp(float(payload["wm_decay_rate"]), 0.0, 1.0)
        if "wm_motor_gain" in payload:
            sim.config["wm_motor_gain"] = clamp(float(payload["wm_motor_gain"]), 0.0, 5.0)

        new_det = float(sim.config.get("deterministic", 0.0))
        new_seed = sim.config.get("seed")

        det_enabled = new_det > 0.5 and new_seed is not None
        det_changed = (prev_det <= 0.5 and det_enabled) or (prev_seed != new_seed and det_enabled)

        if det_enabled and det_changed:
            sim.reseed(new_seed)
            sim.deterministic_reset()

        sim.apply_runtime_config()

        response = {"status": "updated", "config": sim.config}
        if det_enabled and new_seed is None:
            response["warning"] = "Determinism requires a seed value."

        return jsonify(response)


@app.route("/maps/list", methods=["GET"])
def list_maps():
    maps = load_custom_maps_data()
    # Expose a synthetic option for generating a fresh random maze
    return jsonify({"maps": ["__random__"] + list(maps.keys())})


@app.route("/maps/save", methods=["POST"])
def save_map():
    req = request.json or {}
    name = req.get("name")
    grid = req.get("grid")

    if not name or not grid:
        return jsonify({"error": "Invalid data"}), 400

    data = load_custom_maps_data()
    data[name] = grid
    save_custom_maps_data(data)
    return jsonify({"status": "saved", "name": name})


@app.route("/maps/load", methods=["POST"])
def load_map():
    req = request.json or {}
    name = req.get("name")
    data = load_custom_maps_data()

    with sim_lock:
        if name == "__random__":
            sim.generate_map()
            new_grid = sim.occupancy_grid
        else:
            if name not in data:
                return jsonify({"error": "Map not found"}), 404
            new_grid = np.array(data[name], dtype=int)

        if not sim._apply_custom_grid(new_grid):
            return jsonify({"error": "Invalid map size"}), 400
        safe_pos = sim.rat_pos.tolist()

        walls = []
        for y in range(sim.map_size):
            for x in range(sim.map_size):
                if sim.occupancy_grid[y, x] == 1:
                    walls.append([x, y, 1, 1])

        return jsonify({"status": "loaded", "walls": walls, "rat": safe_pos})


def brain_fingerprint(sim: SimulationState) -> str:
    h = hashlib.sha256()
    h.update(sim.brain.basal_ganglia.w_gate.astype(np.float64).tobytes())
    h.update(sim.brain.basal_ganglia.w_motor.astype(np.float64).tobytes())
    
    # OLD: h.update(sim.brain.soma.psi...)
    # NEW: Use Interface
    h.update(sim.brain.soma.get_fingerprint_bytes())
    h.update(sim.brain.mt_theta.get_fingerprint_bytes())
    
    h.update(sim.brain.grid_phases.astype(np.float64).tobytes())
    h.update(sim.brain.hd_cells.astype(np.float64).tobytes())
    return h.hexdigest()


def compute_checksum(sim: SimulationState, state: Dict[str, Any]) -> str:
    payload = {
        "rat": state["rat"],
        "predator": state["predator"],
        "targets": state["targets"],
        "brain": brain_fingerprint(sim),
    }
    # Use compact separators and sort keys to ensure consistent serialization
    dump = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(dump.encode("utf-8")).hexdigest()


@app.route("/determinism_check", methods=["POST"])
def determinism_check():
    payload = request.json or {}
    seed = int(payload.get("seed", 0))
    steps = int(max(1, payload.get("steps", 10)))
    with sim_lock:
        sim.config["deterministic"] = 1.0
        sim.config["seed"] = seed
        sim.reseed(seed)
        sim.deterministic_reset()
        sim.apply_runtime_config()

    checksums = []
    for _ in range(steps):
        with app.test_request_context("/step", method="POST", json={"batch_size": 1}):
            resp = step()
        data = resp.get_json()
        checksums.append(compute_checksum(sim, data))

    return jsonify({"seed": seed, "steps": steps, "checksums": checksums})


if __name__ == "__main__":
    # For a single-user demo: avoid threading surprises
    app.run(debug=True, port=5000, threaded=False, use_reloader=False)
